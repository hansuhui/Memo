from django.apps import AppConfig


class HappConfig(AppConfig):
    name = 'happ'
