<?php
if (!defined('_GNUBOARD_')) exit;



//작가수익 30원
if($a_type == "voice")	$set2[writer_fee] = 10;
elseif($a_type == "graphic")	$set2[writer_fee] = 10;
else $set2[writer_fee] = 30;




// Pay Means
function apms_pay_flag($flag) {

	switch($flag) {
		case '1'	: $flag = '신청금액'; break;
		case '2'	: $flag = '신청금액 - 부가세'; break;
		case '3'	: $flag = '신청금액 - 부가세 - 제세공과(원천징수 3.3%)'; break;
		case '4'	: $flag = '기타'; break;
		case '5'	: $flag = '신청금액 - 제세공과(원천징수 3.3%)'; break;
		default		: $flag = '미등록'; break;
	}

	return $flag;
}

function apms_pay_amount($row) {

	if($row['pp_means'] == "1") { // 포인트 전환
		$pay = ($row['pp_amount'] - $row['pp_vat']); 
		$shingo = 0;
		$tax = 0; 
	} else {
		switch($row['pp_flag']) {
			case '1'	: 
				$pay = $row['pp_amount']; 
				$shingo = $row['pp_amount']; 
				$tax = 0; 
				break;
			case '2'	: 
				$pay = ($row['pp_amount'] - $row['pp_vat']); 
				$shingo = ($row['pp_amount'] - $row['pp_vat']); 
				$tax = 0; 
				break;
			case '3'	: 
				$shingo = ($row['pp_amount'] - $row['pp_vat']);
				$tax = ceil($shingo * 0.033);
				$pay = ($row['pp_amount'] - $row['pp_vat'] - $tax); 
				break;
			case '5'	: 
				$row['pp_vat'] = 0;
				$shingo = ($row['pp_amount'] - $row['pp_vat']);
				$tax = ceil($shingo * 0.033);
				$pay = ($row['pp_amount'] - $row['pp_vat'] - $tax); 
				break;
			default		: 
				$shingo = 0;
				$tax = 0;
				$pay = 0; 
				break;
		}
	}

	$pp = array('pay'=>$pay, 'shingo'=>$shingo, 'tax'=>$tax);	

	return $pp;
}


// Balance Sheet
function apms_balance_sheet($mb_id) {
    global $g5, $apms, $set2, $a_type;
	
	$table = "love_coin_log";

	if(!$mb_id) return;

	$account = array();

	if($mb_id == 'admin'){
		$sql = " select sum(coin) as coin from `$table` where type='EPISODE' and reg_date > '2015-12-01' and reg_date < date_format(curdate( ), '%Y-%m-%d' ) ";
	}else{
		$mb_sql = " and mb_id='$mb_id'";

		//계정현황
		
		if($a_type == "voice")	$sql_common = " where voice_id = '{$mb_id}'";
		elseif($a_type == "graphic")	$sql_common = " where graphic_id = '{$mb_id}'";
		else $sql_common = " where author_id = '{$mb_id}'";


		$sql = " select uid from `love_bid` $sql_common";
		$result = sql_query($sql);
		for ($i=0; $row_id=sql_fetch_array($result); $i++) {
			if ($row_id[uid]) {
				$where[] = " bid = $row_id[uid] ";
			}
		}
		if ($where) {
			//$sql_search = ' where '.implode(' and ', $where);
			$sql_search = implode(' or ', $where);
		}
		// 회원 작품 bid 검색

		$sql = " select sum(coin) as coin from `$table` where type='EPISODE' and reg_date > '2015-12-01' and reg_date < date_format(curdate( ), '%Y-%m-%d' ) and ($sql_search)";
	}

	$row = sql_fetch($sql);

	$account['sale'] = $row['coin'] * $set2[writer_fee];

	//$account['commission'] = $account['sale'] * $set2[tax];

	//지급액
	$sql = " select sum(pp_amount) as pay from love_payment where pp_confirm = '1' $mb_sql";
	$row = sql_fetch($sql);
	$account['payment'] = $row['pay'];

	//요청액
	$sql = " select sum(pp_amount) as request from love_payment where pp_confirm = '0' $mb_sql";
	$row = sql_fetch($sql);
	$account['request'] = $row['request'];


	$account['netgross'] = $account['sale'] - $account['commission'];
	//신청가능액 - 잔액
	$account['balance'] = $account['netgross'] - $account['payment'] - $account['request'];

	//출금기준
	//	$account['deposit'] = 10000;

	//신청가능액
	$possible = $account['balance'] - $account['deposit'];
	$account['possible'] = ($possible > 0) ? $possible : 0;

	//신청단위 & 자릿수
	if($apms['apms_payment_cut']) {
		$account['unit'] = 1000;
		$account['num'] = 3;
		$account['txt'] = '000';
	} else {
		$account['unit'] = 10000;
		$account['num'] = 4;
		$account['txt'] = '0000';
	}

	// 최대금액
	$account['max'] = ((int)($account['possible'] / $account['unit'])) * $account['unit'];


    return $account;
}




// Balance Sheet
function apms_depositconfirm_sheet($pid) {
	$table = "love_payment";


	$account = array();

	$sql = " select * from `$table` where pp_id = ".$pid;
	$row = sql_fetch($sql);


	$account['pp_id'] = $row['uid'];
	$account['mb_id'] = $row['mb_id'];
	$account['pp_amount'] = $row['pp_amount'];
	$account['pp_confirm'] = $row['pp_confirm'];

    return $account;
}






?>