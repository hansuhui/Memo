<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

$seometa = array();
if($is_seometa == 'view') { //게시물

	$seometa['title'] = htmlspecialchars(apms_get_text($write['wr_subject']));
	$seometa['desc'] = htmlspecialchars(apms_cut_text($write['wr_content'], 200));
	$seometa['publisher'] = htmlspecialchars(apms_get_text($config['cf_title']));
	$seometa['creator'] = htmlspecialchars(apms_get_text($write['wr_name']));
	$seometa['keyword'] = apms_seo_keyword($write['as_tag'], $write['ca_name']);
	$seometa['url'] = G5_BBS_URL.'/board.php?bo_table='.$bo_table.'&amp;wr_id='.$wr_id;
	$seometa['img'] = apms_wr_thumbnail($bo_table, $write, 0, 0); // 썸네일
	echo '<meta name="title" content="'.$seometa['title'].'" />'.PHP_EOL;
	echo '<meta name="subject" content="'.$seometa['title'].'" />'.PHP_EOL;
	echo '<meta name="publisher" content="'.$seometa['publisher'].'" />'.PHP_EOL;
	echo '<meta name="author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta name="robots" content="index,follow" />'.PHP_EOL;
	if($seometa['keyword']) {
		echo '<meta name="keywords" content="'.htmlspecialchars(apms_get_text($seometa['keyword'])).'" />'.PHP_EOL;
	}
	if($seometa['desc']) {
		echo '<meta name="description" content="'.$seometa['desc'].'" />'.PHP_EOL;
	}
	echo '<meta property="og:title" content="'.$seometa['title'].'"/>'.PHP_EOL;
	echo '<meta property="og:site_name" content="'.$seometa['publisher'].'"/>'.PHP_EOL;
	echo '<meta property="og:author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta property="og:url" content="'.$seometa['url'].'"/>'.PHP_EOL;
	if($seometa['desc']) {
		echo '<meta property="og:description" content="'.$seometa['desc'].'"/>'.PHP_EOL;
	}
	if($seometa['img']['src']) {
		echo '<meta property="og:image" content="'.$seometa['img']['src'].'"/>'.PHP_EOL;
	}
	echo '<link rel="canonical" href="'.G5_BBS_URL.'/board.php?bo_table='.$bo_table.'&amp;wr_id='.$wr_id.'" />'.PHP_EOL;

} else if($is_seometa == 'it') { // 상품

	$seometa['title'] = htmlspecialchars(apms_get_text($it['it_name']));
	$seometa['desc'] = ($it['it_basic']) ? htmlspecialchars(apms_get_text($it['it_basic'])) : htmlspecialchars(apms_cut_text($it['it_explan'], 200));
	$seometa['publisher'] = htmlspecialchars(apms_get_text($config['cf_title']));
	$seometa['creator'] = ($author['mb_nick']) ? htmlspecialchars($author['mb_nick']) : $seometa['publisher'];
	$seometa['keyword'] = apms_seo_keyword($it['pt_tag']);
	$seometa['url'] = G5_SHOP_URL.'/item.php?it_id='.$it['it_id'];
	$seometa['img'] = apms_it_thumbnail($it, 0, 0, false, true);

	echo '<meta name="title" content="'.$seometa['title'].'" />'.PHP_EOL;
	echo '<meta name="subject" content="'.$seometa['title'].'" />'.PHP_EOL;
	echo '<meta name="publisher" content="'.$seometa['publisher'].'" />'.PHP_EOL;
	echo '<meta name="author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta name="robots" content="index,follow" />'.PHP_EOL;
	if($seometa['keyword']) {
		echo '<meta name="keywords" content="'.htmlspecialchars(apms_get_text($seometa['keyword'])).'" />'.PHP_EOL;
	}
	if($seometa['desc']) {
		echo '<meta name="description" content="'.$seometa['desc'].'" />'.PHP_EOL;
	}
	echo '<meta property="og:title" content="'.$seometa['title'].'"/>'.PHP_EOL;
	echo '<meta property="og:site_name" content="'.$seometa['publisher'].'"/>'.PHP_EOL;
	echo '<meta property="og:author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta property="og:url" content="'.$seometa['url'].'"/>'.PHP_EOL;
	if($seometa['desc']) {
		echo '<meta property="og:description" content="'.$seometa['desc'].'"/>'.PHP_EOL;
	}
	if($seometa['img']['src']) {
		echo '<meta property="og:image" content="'.$seometa['img']['src'].'"/>'.PHP_EOL;
	}
	echo '<link rel="canonical" href="'.G5_SHOP_URL.'/item.php?it_id='.$it_id.'" />'.PHP_EOL;

} else if($is_seometa == 'iqa') { //상품문의

	$seometa['title'] = htmlspecialchars(apms_get_text($view['iq_subject']).' < '.$view['it_name'].' < '.$config['cf_title']);
	$seometa['subject'] = htmlspecialchars(apms_get_text($view['iq_subject']));
	$seometa['desc'] = htmlspecialchars(apms_cut_text($view['iq_content'], 200));
	$seometa['publisher'] = htmlspecialchars(apms_get_text($config['cf_title']));
	$seometa['creator'] = htmlspecialchars(apms_get_text($view['iq_name']));
	$seometa['keyword'] = apms_seo_keyword($view['pt_tag']);
	$seometa['url'] = G5_SHOP_URL.'/itemqaview.php?iq_id='.$iq_id;
	$seometa['img'] = apms_it_write_thumbnail($view['it_id'], $view['iq_content'], 0, 0);

	echo '<meta name="title" content="'.$seometa['title'].'" />'.PHP_EOL;
	echo '<meta name="subject" content="'.$seometa['subject'].'" />'.PHP_EOL;
	echo '<meta name="publisher" content="'.$seometa['publisher'].'" />'.PHP_EOL;
	echo '<meta name="author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta name="robots" content="index,follow" />'.PHP_EOL;
	if($seometa['keyword']) {
		echo '<meta name="keywords" content="'.htmlspecialchars(apms_get_text($seometa['keyword'])).'" />'.PHP_EOL;
	}
	echo '<meta name="description" content="'.$seometa['desc'].'" />'.PHP_EOL;
	echo '<meta property="og:title" content="'.$seometa['title'].'"/>'.PHP_EOL;
	echo '<meta property="og:site_name" content="'.$seometa['publisher'].'"/>'.PHP_EOL;
	echo '<meta property="og:author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta property="og:url" content="'.$seometa['url'].'"/>'.PHP_EOL;
	echo '<meta property="og:description" content="'.$seometa['desc'].'"/>'.PHP_EOL;
	if($seometa['img']['src']) {
		echo '<meta property="og:image" content="'.$seometa['img']['src'].'"/>'.PHP_EOL;
	}
	echo '<link rel="canonical" href="'.G5_SHOP_URL.'/itemqaview.php?iq_id='.$iq_id.'" />'.PHP_EOL;

} else if($is_seometa == 'iuse') { //상품후기

	$seometa['title'] = htmlspecialchars(apms_get_text($view['is_subject']).' < '.$view['it_name'].' < '.$config['cf_title']);
	$seometa['subject'] = htmlspecialchars(apms_get_text($view['is_subject']));
	$seometa['desc'] = htmlspecialchars(apms_cut_text($view['is_content'], 200));
	$seometa['publisher'] = htmlspecialchars(apms_get_text($config['cf_title']));
	$seometa['creator'] = htmlspecialchars(apms_get_text($view['is_name']));
	$seometa['keyword'] = apms_seo_keyword($view['pt_tag']);
	$seometa['url'] = G5_SHOP_URL.'/itemuseview.php?is_id='.$is_id;
	$seometa['img'] = apms_it_write_thumbnail($view['it_id'], $view['is_content'], 0, 0);

	echo '<meta name="title" content="'.$seometa['title'].'" />'.PHP_EOL;
	echo '<meta name="subject" content="'.$seometa['subject'].'" />'.PHP_EOL;
	echo '<meta name="publisher" content="'.$seometa['publisher'].'" />'.PHP_EOL;
	echo '<meta name="author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta name="robots" content="index,follow" />'.PHP_EOL;
	if($seometa['keyword']) {
		echo '<meta name="keywords" content="'.htmlspecialchars(apms_get_text($seometa['keyword'])).'" />'.PHP_EOL;
	}
	echo '<meta name="description" content="'.$seometa['desc'].'" />'.PHP_EOL;
	echo '<meta property="og:title" content="'.$seometa['title'].'"/>'.PHP_EOL;
	echo '<meta property="og:site_name" content="'.$seometa['publisher'].'"/>'.PHP_EOL;
	echo '<meta property="og:author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta property="og:url" content="'.$seometa['url'].'"/>'.PHP_EOL;
	echo '<meta property="og:description" content="'.$seometa['desc'].'"/>'.PHP_EOL;
	if($seometa['img']['src']) {
		echo '<meta property="og:image" content="'.$seometa['img']['src'].'"/>'.PHP_EOL;
	}
	echo '<link rel="canonical" href="'.G5_SHOP_URL.'/itemuseview.php?is_id='.$is_id.'" />'.PHP_EOL;

} else if($is_seometa == 'page') { // 페이지

	$seometa['title'] = htmlspecialchars(apms_get_text($g5['title']).' < '.$config['cf_title']);
	$seometa['subject'] = ($at['subject']) ? htmlspecialchars(apms_get_text($at['subject'])) : htmlspecialchars(apms_get_text($g5['title']));
	$seometa['desc'] = ($at['desc']) ? htmlspecialchars(apms_get_text($at['desc'])) : $seometa['subject'];
	$seometa['publisher'] = htmlspecialchars(apms_get_text($config['cf_title']));
	$seometa['creator'] = $seometa['publisher'];
	$seometa['keyword'] = apms_seo_keyword($at['subject']);
	$seometa['url'] = G5_BBS_URL.'/page.php?hid='.$hid;

	echo '<meta name="title" content="'.$seometa['title'].'" />'.PHP_EOL;
	echo '<meta name="subject" content="'.$seometa['subject'].'" />'.PHP_EOL;
	echo '<meta name="publisher" content="'.$seometa['publisher'].'" />'.PHP_EOL;
	echo '<meta name="author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta name="robots" content="index,follow" />'.PHP_EOL;
	echo '<meta name="keywords" content="'.htmlspecialchars(apms_get_text($seometa['keyword'])).'" />'.PHP_EOL;
	echo '<meta name="description" content="'.$seometa['desc'].'" />'.PHP_EOL;
	echo '<meta property="og:title" content="'.$seometa['title'].'"/>'.PHP_EOL;
	echo '<meta property="og:site_name" content="'.$seometa['publisher'].'"/>'.PHP_EOL;
	echo '<meta property="og:author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta property="og:url" content="'.$seometa['url'].'"/>'.PHP_EOL;
	echo '<meta property="og:description" content="'.$seometa['desc'].'"/>'.PHP_EOL;
	echo '<link rel="canonical" href="'.G5_BBS_URL.'/page.php?hid='.$hid.'" />'.PHP_EOL;

} else if($is_seometa == 'content') { // 컨텐츠

	$seometa['title'] = htmlspecialchars(apms_get_text($g5['title']).' < '.$config['cf_title']);
	$seometa['subject'] = ($at['subject']) ? htmlspecialchars(apms_get_text($at['subject'])) : htmlspecialchars(apms_get_text($g5['title']));
	$seometa['desc'] = htmlspecialchars(apms_cut_text($co['co_content'], 200));
	$seometa['publisher'] = htmlspecialchars(apms_get_text($config['cf_title']));
	$seometa['creator'] = $seometa['publisher'];
	$seometa['keyword'] = apms_seo_keyword($g5['title']);
	$seometa['url'] = G5_BBS_URL.'/content.php?co_id='.$co_id;

	echo '<meta name="title" content="'.$seometa['title'].'" />'.PHP_EOL;
	echo '<meta name="subject" content="'.$seometa['subject'].'" />'.PHP_EOL;
	echo '<meta name="publisher" content="'.$seometa['publisher'].'" />'.PHP_EOL;
	echo '<meta name="author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta name="robots" content="index,follow" />'.PHP_EOL;
	echo '<meta name="keywords" content="'.htmlspecialchars(apms_get_text($seometa['keyword'])).'" />'.PHP_EOL;
	echo '<meta name="description" content="'.$seometa['desc'].'" />'.PHP_EOL;
	echo '<meta property="og:title" content="'.$seometa['title'].'"/>'.PHP_EOL;
	echo '<meta property="og:site_name" content="'.$seometa['publisher'].'"/>'.PHP_EOL;
	echo '<meta property="og:author" content="'.$seometa['creator'].'" />'.PHP_EOL;
	echo '<meta property="og:url" content="'.$seometa['url'].'"/>'.PHP_EOL;
	echo '<meta property="og:description" content="'.$seometa['desc'].'"/>'.PHP_EOL;
	echo '<link rel="canonical" href="'.G5_BBS_URL.'/content.php?co_id='.$co_id.'" />'.PHP_EOL;
}

unset($seometa);
?>