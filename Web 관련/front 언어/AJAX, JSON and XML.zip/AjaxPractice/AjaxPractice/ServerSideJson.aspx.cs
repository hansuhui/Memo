﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Web.Script.Serialization;

namespace AjaxPractice
{
    
    public class DataSetConverter : JavaScriptConverter
    {
        public override object Deserialize(System.Collections.Generic.IDictionary<string, object> dictionary, Type type, JavaScriptSerializer serializer)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override System.Collections.Generic.IDictionary<string, object> Serialize(object obj, JavaScriptSerializer serializer)
        {
            Dictionary<string, object> dtDic = new Dictionary<string, object>();

            DataSet ds = obj as DataSet;


            foreach (DataTable dt in ds.Tables)
            {
                Dictionary<string, object> rowDic = new Dictionary<string, object>();
                int i = 0;
                foreach (DataRow row in dt.Rows)
                {
                    Dictionary<string, object> colDic = new Dictionary<string, object>();
                    foreach (DataColumn col in row.Table.Columns)
                    {
                        colDic.Add(col.ColumnName, row[col]);
                    }
                    rowDic.Add("row" + (i++).ToString(), colDic);
                }

                dtDic.Add(dt.TableName, rowDic);
            }

            return dtDic;
            
        }

        public override System.Collections.Generic.IEnumerable<Type> SupportedTypes
        {
            get { return new ReadOnlyCollection<Type>(new List<Type>(new Type[] { typeof(DataSet) })); }

        }
    }

    public partial class ServerSideJson : System.Web.UI.Page
    {
        public class Hero
        {
            public string Name;
            public int Age;

            public string  GetName()
            {
                return Name;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request["job"] == null)
                ConvertObjectToJson();
            else
            {
                string job = Request["job"].ToString();

                switch (job)
                {
                    case "0":
                        ConvertObjectToJson();
                        break;
                    case "1":
                        ConvertDataSetToJson();
                        break;
                }
            }

            return;

        }

        // 간단한 구조체를 JSON으로 변환
        private void ConvertObjectToJson()
        {
            Hero hero = new Hero();
            hero.Name = "홍길동";
            hero.Age = 18;

            JavaScriptSerializer jss = new JavaScriptSerializer();
            string jsonHero = jss.Serialize(hero);
            

            Response.ContentType = "text/plain";
            Response.Write(jsonHero);
            Response.End();
        }

        // 데이터셋을 JSON으로 변환
        private void ConvertDataSetToJson()
        {
            DataSet ds = new DataSet();

            DataTable dt = new DataTable("Table");
            dt.Columns.Add(new DataColumn("Name", Type.GetType("System.String")));
            dt.Columns.Add(new DataColumn("Age", Type.GetType("System.Int32")));

            DataRow row = dt.NewRow();
            row["Name"] = "홍길동";
            row["Age"] = 20;

            dt.Rows.Add(row);

            ds.Tables.Add(dt);

            JavaScriptSerializer jss = new JavaScriptSerializer();

            jss.RegisterConverters(new JavaScriptConverter[] { new DataSetConverter() });

            string jsonDs = jss.Serialize(ds);

            Response.ContentType = "text/plain";
            Response.Write(jsonDs);
            Response.End();
        }

    }
}
