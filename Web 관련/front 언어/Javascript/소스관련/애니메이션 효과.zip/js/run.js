

$(document).ready(function(){
	$.fn.animateBP = function (c, d, e) {
		var b = null !== navigator.userAgent.match(/MSIE [678]\./) && null === navigator.userAgent.match(/Trident\/5\.0/), a = []; !0 == b ? (a.push(this.css("background-position-x")), a.push(this.css("background-position-y"))) : a = this.css("background-position").split(" "); this.x = parseInt(a[0]) || 0; this.y = parseInt(a[1]) || 0;
		$.Animation(this, { x: c, y: d }, { duration: e }).progress(function (a) { !0 == b ? this.css({ "background-position-x": a.tweens[0].now + "px", "background-position-y": a.tweens[1].now + "px" }) : this.css("background-position", a.tweens[0].now + "px " + a.tweens[1].now + "px") }); return this
	};
	// dom loaded
		var gnbsys=0;
		//function list
		function gnbslide(c,i){
			function gnbslide(c, i) {
				// gnb bar focus,mouseenter event method
				var x = "";
				if (c.attr("class") == "btn-2")
				{
					x="0px"
				}
				if (c.attr("class") == "btn-3") {
					x = "-80px"
				}
				if (c.attr("class") == "btn-4") {
					x = "-160px"
				}
				if (c.attr("class") == "btn-5") {
					x = "-240px"
				}
				if (c.attr("class") == "btn-6") {
					x = "-290px"
				}
				if (c.attr("class") == "btn-7") {
					x = "-370px"
				}
				
				if (i == -140) {
					//$(c).animate({ 'background-position': '0px -140px' });
										
					$(c).animateBP(x,'-140px',200);
					
				}
				if (i == -110) {
					//$(c).animate({ 'backgroundPosition-y': -110 }, 'fast');
					$(c).animateBP(x, '-110px', 200);
				}

			};
		$(window).on('load',function(){
			$('.investors-text-2').hide();
			$('#main_box, #main_box div, .bg-img1, .bg-img2, .bg-img3').width($(window).width());
			$("#main_box").slidesjs({
				width: $(window).width(),
				height: 450,
				navigation:false,
				play: {
				 active: true,
				 effect: "fade",
				interval: 3500,
				auto: true,
				swap: false,
				pauseOnHover: true,
				restartDelay: 2500
				}
			 });
		})
		$(window).on('load resize',function(){
		// window loaded
			borderC1=setInterval(function(){
			// border color change set Interval
			$('.header-wrap').animate({'borderColor':'#676767'},800).delay(1500).animate({'borderColor':'#da2128'},800).delay(3000);
			},3000);
			$('#main_box, #main_box div, .bg-img1, .bg-img2, .bg-img3').width($(window).width());
			$("#main_box").slidesjs({
				width: $(window).width(),
				height: 450
			 });
		})
	// gnb mouse enter, leave event,
	$('#gnb').find('>ul li a').on('focus mouseover',function(){
		gnbsys=$('#gnb').find('>ul li a').index($(this));
		if($('#gnb').find('>ul li a').parent().eq(gnbsys).hasClass('arrow-li')){
		}
		else{
		gnbslide($(this),-140);
		}
	}).on('mouseleave',function(){
		if($('#gnb').find('>ul li a').parent().eq(gnbsys).hasClass('arrow-li')){
		}
		else{
		gnbslide($(this),-110);
		}
	}).on('focus click',function(){
		$('#gnb').find('>ul li a span').remove().end().find('>ul li').removeClass('arrow-li').end().find('>ul li a').css({'backgroundPosition-y':-110});
		gnbidx=$('#gnb').find('>ul li a').index($(this));
		if(gnbidx==0 || gnbidx==2 || gnbidx==3 || gnbidx==4){
//		gnbsys=gnbidx;
		$('#gnb').find('>ul li a').eq(gnbidx).css({'backgroundPosition-y':-140}).html('<span class="arrow">화살표</span>').parent().addClass('arrow-li');
		$('#nav').slideDown();
		return false;
		}
	});
	// nav mouseleave event,
	$('#nav').on('mouseleave',function(){
		$(this).slideUp();
		$('#gnb').find('>ul li a span').remove().end().find('>ul li').removeClass('arrow-li');
		$('#gnb').find('>ul li a').css({'backgroundPosition-y':-110});
	}).find('.nav-wrap>ul').on('mouseenter',function(){
		navidx=$('#nav').find('.nav-wrap>ul').index($(this));
		if(navidx==0){
			$('#gnb').find('>ul li a span').remove().end().find('>ul li').removeClass('arrow-li').end().find('>ul li a').css({'backgroundPosition-y':-110});
			$('#gnb').find('>ul li a').eq(navidx).animate({'backgroundPosition-y':-140},'fast').html('<span class="arrow">화살표</span>').parent().addClass('arrow-li');
		}
		else if(navidx==1){
			navidx=navidx+1;
			$('#gnb').find('>ul li a span').remove().end().find('>ul li').removeClass('arrow-li').end().find('>ul li a').css({'backgroundPosition-y':-110});
			$('#gnb').find('>ul li a').eq(navidx).animate({'backgroundPosition-y':-140},'fast').html('<span class="arrow">화살표</span>').parent().addClass('arrow-li');
		}
		else if(navidx==2){
			navidx=navidx+1;
			$('#gnb').find('>ul li a span').remove().end().find('>ul li').removeClass('arrow-li').end().find('>ul li a').css({'backgroundPosition-y':-110});
			$('#gnb').find('>ul li a').eq(navidx).animate({'backgroundPosition-y':-140},'fast').html('<span class="arrow">화살표</span>').parent().addClass('arrow-li');
		}
		else if(navidx==3){
			navidx=navidx+1;
			$('#gnb').find('>ul li a span').remove().end().find('>ul li').removeClass('arrow-li').end().find('>ul li a').css({'backgroundPosition-y':-110});
			$('#gnb').find('>ul li a').eq(navidx).animate({'backgroundPosition-y':-140},'fast').html('<span class="arrow">화살표</span>').parent().addClass('arrow-li');
		}
	})

	$('.select-title').on('click',function(){
		// footer select-box is click the slide Up ul list
		$('.select-list').css({'zIndex':60,'top':-30}).animate({'height':493,'top':-493},'slow');
		$('.select-title').find('p i').removeClass('fa fa-chevron-circle-down').addClass('fa fa-chevron-circle-up');
	})
	$('#select_box').on('mouseleave',function(){
		// footer select-box is mouseleave the slide Down ul list
		$('.select-list').stop().css({'height':30,'top':0,'zIndex':0});
		$('.select-title').find('p i').removeClass('fa fa-chevron-circle-up').addClass('fa fa-chevron-circle-down');	
	})
	$('.investors').find('.prev-next-btn a').on('click focus',function(){
		inv=$('.investors').find('.prev-next-btn a').index($(this));
		if(inv==0){
		$('.investors-text').find('>div').hide().eq(inv).fadeIn();
		}
		else{
		$('.investors-text').find('>div').hide().eq(inv).fadeIn();		
		}
		return false;
	})
})