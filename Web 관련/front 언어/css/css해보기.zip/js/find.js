
function subControl(subId){
	for (var i=1;i<3;i++)
	{
		if (i==subId)
		{
		document.getElementById("sub"+subId).style.display="block"
		document.getElementById("tabimg"+subId).src=document.getElementById("tabimg"+subId).src.replace("on","off")
		}else{
		document.getElementById("sub"+i).style.display="none"
		document.getElementById("tabimg"+i).src=document.getElementById("tabimg"+i).src.replace("off","on")
		}//end if
	}//end for
}//end function

var findbox=document.getElementById("findbox")
var tab=findbox.getElementsByTagName("h2")

for (var i=0;i<tab.length;i++)
{
	var tabBtn=tab[i].firstChild
	tabBtn.onclick=function(){
	//클릭되는 a요소의 부모요소인 h2의 클래스명 값의 문자열 중 index6번
	//의 문자값 추출
	var link=this.parentNode.className.charAt(3)//substr(5,1)
	subControl(link)
	return false;
	}//end click
}//end for
