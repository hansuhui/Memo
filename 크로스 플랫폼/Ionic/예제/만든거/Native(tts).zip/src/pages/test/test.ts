import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { TextToSpeech } from '@ionic-native/text-to-speech';

@Component({
  selector: 'page-test',
  templateUrl: 'test.html'
})
export class TestPage {

Speak:string = "";

  constructor(public navCtrl: NavController,private tts: TextToSpeech) {
    this.tts.speak('Hello Native')
    .then(() => console.log('Success'))
    .catch((reason: any) => console.log(reason));
  }


SpeakTest(){
      if(this.Speak==""){
        this.Speak ="No Text"
      }

    this.tts.speak({text:this.Speak,locale:"ko-KR",rate:1});
    
    if(this.Speak=="No Text"){
        this.Speak =""
      }

      
  }

}
