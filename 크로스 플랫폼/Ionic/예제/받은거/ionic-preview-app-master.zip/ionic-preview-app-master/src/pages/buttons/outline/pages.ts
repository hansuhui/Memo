import { Component } from '@angular/core';


@Component({
  templateUrl: 'outline.html'
})
export class OutlinePage { }
