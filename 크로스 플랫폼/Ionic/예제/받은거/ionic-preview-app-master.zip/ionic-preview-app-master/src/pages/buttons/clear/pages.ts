import { Component } from '@angular/core';

@Component({
  templateUrl: 'clear.html'
})
export class ClearPage { }
