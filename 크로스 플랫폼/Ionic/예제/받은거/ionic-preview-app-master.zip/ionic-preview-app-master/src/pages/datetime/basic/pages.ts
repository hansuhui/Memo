import { Component } from '@angular/core';


@Component({
  templateUrl: 'template.html'
})
export class BasicPage {
  public event = {
    month: '1990-02-19',
    timeStarts: '07:43',
    timeEnds: '1990-02-20'
  }


}
