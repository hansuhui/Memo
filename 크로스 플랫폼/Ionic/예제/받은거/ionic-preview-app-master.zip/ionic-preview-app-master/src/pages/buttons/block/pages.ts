import { Component } from '@angular/core';


@Component({
  templateUrl: 'block.html'
})
export class BlockPage { }
