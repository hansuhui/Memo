﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;

namespace CShapType
{
    class Program
    {
        static void Main(string[] args)
        {
            #region 에제 코드
            ClassTypeCheck Check = new ClassTypeCheck();

            ExampleA expA = new ExampleA();
            expA.id = 1001;
            expA.name = "Test";
            expA.strength = 50.5f;

            ExampleB expB = new ExampleB();
            expB.id = 1002;
            expB.name = "Test2";
            expB.defense = 59.5f;

            ExampleC expC = new ExampleC();
            expC.id = 1003;
            expC.name = "Test3";
            expC.strength = 53.5f;

            ExampleD expD = new ExampleD();
            expD.id = 1004;
            expD.name = "Test4";
            expD.defense = 55.5f;


            Console.WriteLine("-------- GetFileds ---------");
            Check.GetFields<ExampleA>(expA);
            Check.GetFields<ExampleB>(expB);
            Check.GetFields<ExampleC>(expC);
            Check.GetFields<ExampleD>(expD);


            Console.WriteLine("-------- GetProperties ---------");
            Check.GetProperties<ExampleA>(expA);
            Check.GetProperties<ExampleB>(expB);
            Check.GetProperties<ExampleC>(expC);
            Check.GetProperties<ExampleD>(expD);

            Console.WriteLine("-------- GetID ---------");
            Console.WriteLine(Check.GetID<ExampleA>(expA));
            Console.WriteLine(Check.GetID<ExampleB>(expB));
            Console.WriteLine(Check.GetID<ExampleC>(expC));
            Console.WriteLine(Check.GetID<ExampleD>(expD));


            ExampleE expE = new ExampleE();
            Console.WriteLine("-------- GetMethod ---------");
            Check.GetMethod<ExampleE>(expE);


            #endregion

            //ParamsTest.Check("asdasd", "123", 123, 1.1f, new ParamsTest());
            
        }
    }

    public class ParamsTest
    {
        public string test { get; set; }

        public static void Check(string fmt, params object[] args)
        {
            foreach (var s in args)
            {
                string Type = s.GetType().FullName;
            }
        }
    }

    public class ClassTypeCheck
    {

        public void GetFields<T>(T obj)
        {
            FieldInfo[] fields = typeof(T).GetFields();

            foreach (FieldInfo filed in fields)
            {
                Console.WriteLine(string.Format("{0}.{1} = {2}", typeof(T).Name, filed.Name, filed.GetValue(obj)));
            }
        }

        public void GetProperties<T>(T obj)
        {
            PropertyInfo[] props = typeof(T).GetProperties();

            foreach (PropertyInfo prop in props)
            {
                Console.WriteLine(string.Format("{0}.{1} = {2}", typeof(T).Name, prop.Name, prop.GetValue(obj, null)));
            }
        }

        public string GetID<T>(T obj)
        {
            if (typeof(T).GetField("id") != null)
                return typeof(T).GetField("id").GetValue(obj).ToString();
            if (typeof(T).GetProperty("id") != null)
                return typeof(T).GetProperty("id").GetValue(obj, null).ToString();
            else
                return null;
        }

        public void GetMethod<T>(T obj)
        {
            MethodInfo[] methods = typeof(T).GetMethods();

            foreach (MethodInfo method in methods)
            {
                if (!method.ReturnType.Name.Equals("Void")) continue;

                Console.WriteLine("----------------------[메소드 정보]--------------------------------");
                Console.WriteLine("메소드명 : {0}", method.Name);
                object[] param_obj = null;


                ParameterInfo[] Params = method.GetParameters();
                if (Params.Length == 0)
                {
                    Console.WriteLine("파라미터 없음");
                }
                else
                {
                    param_obj = new object[Params.Length];

                    foreach (ParameterInfo Param in Params)
                    {
                        switch (Param.ParameterType.Name)
                        {
                            case "String":
                                param_obj.SetValue("[Test]", (param_obj.Length - 1));
                                break;
                            case "Int32":
                                param_obj.SetValue(999, (param_obj.Length - 1));
                                break;
                            default:
                                break;
                        }

                        Console.WriteLine(string.Format("파라미터[{0}] : {0} - {1}", Param.Position, Param.Name, Param.ParameterType.Name));
                    }
                }

                switch (method.ReturnType.Name)
                {
                    default:
                        Console.WriteLine("반환값 : " + method.ReturnType.Name);
                        break;
                }

                
                Console.Write("메소드실행 - ");
                method.Invoke(obj, param_obj);

                Console.WriteLine("----------------------[메소드 정보 끝]--------------------------------");



            }
        }

    }

    #region 예제 클래스
    public class ExampleA
    {
        public int id;
        public string name;
        public float strength;
    }

    public class ExampleB
    {
        public int id;
        public string name;
        public float defense;
    }

    public class ExampleC
    {
        public int id { get; set; }
        public string name { get; set; }
        public float strength { get; set; }
    }

    public class ExampleD
    {
        public int id { get; set; }
        public string name { get; set; }
        public float defense { get; set; }
    }

    public class ExampleE
    {
        public void Method1() { Console.WriteLine("Method1 실행"); }
        public void Method2(string Msg) { Console.WriteLine(Msg); }
        public void Method3(int Msg) { Console.WriteLine(Msg); }
        public void Method4(string Msg, int Msg2) { Console.WriteLine(Msg + Msg2); }
    }

    #endregion
}
