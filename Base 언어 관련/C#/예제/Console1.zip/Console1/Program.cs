﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections;

namespace Console1
{
    class Program
    {
        //실행 예제
        //new OfType().Main_Ex(args);
        static void Main(string[] args)
        {
            //new XElement_Ex().Main_Ex(args);
            new LINQ_Ex6().Main();
        }
    }

}
