﻿using System;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Collections;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Daemon
{ 
    public class ChildService : Service1
    {
        public ChildService()
        {

        }

        protected override void OnStart(string[] args)
        {
            base.OnStart(args);
        }
        protected override void OnStop()
        {
            base.OnStop();
        }

    }
}
