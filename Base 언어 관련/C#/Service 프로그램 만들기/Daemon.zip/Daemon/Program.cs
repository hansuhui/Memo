﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace Daemon
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            ServiceBase[] servicesToReun;
            
            servicesToReun = new ServiceBase[] { new AdminService() };

            ServiceBase.Run(servicesToReun);


        }
    }
}
