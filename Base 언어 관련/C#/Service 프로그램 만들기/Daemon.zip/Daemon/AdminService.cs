﻿using System;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Collections;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Drawing;


using Daemon.Util;

namespace Daemon
{
    public class AdminService : Service1
    {

        static System.Timers.Timer timer = new System.Timers.Timer();
        public AdminService()
        {
            this.ServiceName = "BizTalkSend";
        }

        protected override void OnStart(string[] args)
        {
            base.OnStart(args);
        }
        protected override void OnStop()
        {
            timer.Stop();
            base.OnStop();
        }

        public override int Execute()
        {


            try
            {

                System.Timers.Timer timer = new System.Timers.Timer();
                timer.Interval = 300000;
                timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
                timer.Start();




            }
            catch (Exception ex)
            {
                string Message = "[오토맨] 에러 발생 - " + ex.Message; ;
                System.Diagnostics.EventLog.WriteEntry("BizTalkSend", Message);
                System.Windows.Forms.MessageBox.Show(Message); 
                Execute();
            }
            return 0;
        }

        void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            new Biztalk().SendCheck();
            new Biztalk().SmSCheck();
        }


    }
}
