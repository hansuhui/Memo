﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;

using IBatisNet.DataMapper;
using Daemon.Models;
using Daemon.Util;




namespace Daemon
{
    class Biztalk
    {


        public void SendCheck()
        {


            //당일 실패한 건에 대해서 3번까지 재전송 시도 
            //일단 설정시간은 5분으로 할 예정
            BizTalkModel Biz = new BizTalkModel();
            Biz.LogTable = string.Format("em_mmt_log_{0:yyyyMM}", DateTime.Now);

            int Count = Mapper.Instance().QueryForObject<int>("BizSendCount", Biz);

            if (Count != 0)
            {
                Mapper.Instance().QueryForObject("BizSend", Biz);
                string Message = string.Format("[오토맨] 비즈톡 발송 [{0:N0}건] - {1:yyyy-MM-dd hh:mm:ss } ", Count, DateTime.Now);
                System.Diagnostics.EventLog.WriteEntry("BizTalkSend", Message);
            }





        }

        public void SmSCheck()
        {


            //취소인걸 불러와서 문자를 보낸다
            BizTalkModel Biz = new BizTalkModel();
            Biz.LogTable = string.Format("em_mmt_log_{0:yyyyMM}", DateTime.Now);
            List<BizTalkModel> List = (List<BizTalkModel>)Mapper.Instance().QueryForList<BizTalkModel>("BizCencelList", Biz);

            int sms = 0;
            int mms = 0;

            foreach (var bizList in List)
            {

                //카톡이 없을때나 차단일떄 
                SmSModel SModel = new SmSModel();
                HSms pUtil = new HSms();

                //문자 발송
                bizList.LogTable = Biz.LogTable;
                SModel.sendphone = bizList.callback;  //발신자 등록이 되어있어야 함
                SModel.sendname = "오토맨";
                SModel.destphone = bizList.recipient_num;
                SModel.destname = "문자시스템";
                SModel.subject = "오토맨"; //입력 안받음
                SModel.reqphone = bizList.callback;  //발신자 등록이 되어있어야 함
                SModel.reqname = "오토맨";
                SModel.msgbody = bizList.content;
                if (bizList.content.Length == 39) { SModel.device = 0; sms++; }
                else { SModel.device = 5; mms++; } //mms로 전송 5             



                //전송 성공시 체크
                string RESULT = pUtil.HsmsSend(SModel);
                if (RESULT == "4100")
                {
                    Mapper.Instance().Update("SmsSet", bizList);
                }

            }


            if (List.Count != 0)
            {
                string Message = string.Format("[오토맨] 문자 발송 [SMS :{0:N0}건 | MMS :{1:N0}건] - {2:yyyy-MM-dd hh:mm:ss } ", sms, mms, DateTime.Now);
                System.Diagnostics.EventLog.WriteEntry("BizTalkSend", Message);
            }

        }

    }
}
