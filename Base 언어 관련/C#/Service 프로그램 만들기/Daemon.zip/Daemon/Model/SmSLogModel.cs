﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Daemon.Models
{
    public class SmSLogModel
    {
        public string REDEVICE { get; set; } 
        public string CMSGID { get; set; } 
        public string MSGID { get; set; } 
        public string PHONE { get; set; }
        public string TO_NAME { get; set; }
        public string UNIXTIME { get; set; }
        public string RESULT { get; set; }
        public string RESULTM { get; set; }
        public string USERDATA { get; set; }
        public string WAPINFO { get; set; }
        public string REPORT { get; set; }
        public string REGDATE { get; set; }
        public string CONTENT { get; set; }
        public string REQPHONE { get; set; }
        public string REQNAME { get; set; }
        

    }
}