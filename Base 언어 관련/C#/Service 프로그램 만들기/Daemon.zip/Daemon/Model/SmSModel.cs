﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Daemon.Models
{
    public class SmSModel
    {
        public string destphone { get; set; } 
        public string destname { get; set; } 
        public string sendphone { get; set; } 
        public string sendname { get; set; }
        public string subject { get; set; }
        public string msgbody { get; set; }
        public string wapurl { get; set; }
        public string reqphone { get; set; }
        public string reqname { get; set; }
        public string SMSSTATE { get; set; }
        public string SMSKEY { get; set; }
        public DateTime REQDATE { get; set; }
        public DateTime VAILDATE { get; set; }
        public bool Cerift { get; set; }
        public int device { get; set; }

    }
}