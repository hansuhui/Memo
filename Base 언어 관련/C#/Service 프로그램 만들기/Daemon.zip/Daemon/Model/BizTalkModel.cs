﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Daemon.Models
{
    public class BizTalkModel
    {
        public int mt_pr { get; set; }
        public string destname { get; set; }
        public string sender_key { get; set; } 
        public string template_code { get; set; } 
        public string LogTable { get; set; }
        public string RepotCode { get; set; }
        public string content { get; set; } 
        public string recipient_num { get; set; } 
        public string callback { get; set; }
        public string SMSSTATE { get; set; }
        public string SMSKEY { get; set; }
        public DateTime REQDATE { get; set; }
        public DateTime VAILDATE { get; set; }
        public string ContentVal1 { get; set; }
        public string ContentVal2 { get; set; }
        public string ContentVal3 { get; set; }
        public string ContentVal4 { get; set; }
        public string ContentVal5 { get; set; }
        public string ContentVal6 { get; set; }
        public string ContentVal7 { get; set; }
        public string ContentVal8 { get; set; }
        public string ContentVal9 { get; set; }
        public string ContentVal10 { get; set; }
        public int PriceVal1 { get; set; }
        public bool Cerift { get; set; }
        public bool IsSMS { get; set; }
        
      
    }
}