﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using IBatisNet.DataMapper;
using Daemon.Models;

namespace Daemon.Util
{

    public class HSms
    {
        public string log { get; set; }
        public string errorMeg { get; set; }
        public string errorCode { get; set; }
        public string Report { get; set; }
        public string Result { get; set; }
        public string sendCheck = "";// "";

        public static string PHONE { get; set; }

        public string HsmsSend(SmSModel sms)
        {
            string RESULT = "";

            //01 블랙리스트 일 경우
            int Black = SmSBlackList(sms.destphone);
            if (Black != 0)
            {
                errorCode = "01";
            }


            if (errorCode == "01")
            {
                errorMeg = "블랙리스트";
            }
            else
            {


                //ks_c_5601-1987  euc-kr
                //Application.CurrentCulture = new System.Globalization.CultureInfo("ko-KR");
                UDSPPURIOX5COMMLib.UdsPPurioX5Class ppurioX5 = new UDSPPURIOX5COMMLib.UdsPPurioX5Class();
                string result;
                DateTime dt;

                //////////////////////////////////////////////////////
                string msgid, unixtime, cinfo, ext;


                string ip = "biz.ppurio.com";
                //string ip = "biztest.ppurio.com"; //테스트

                string port = "5000";
                string id = "antae3212";
                string pass = "an8309221.";
                int device = 0;

                if (sms.device != 0) { device = sms.device; }

                string destphone = sms.destphone; // "받는사람";
                string destname = sms.destname;  //"받는사람 이름";

                string sendphone = sms.sendphone;// "보내는 사람";
                string sendname = sms.sendname;  //"보내는 사람이름";

                string subject = "제목"; // "제목";
                string msgbody = sms.msgbody; // "내용";
                string wapurl = sms.wapurl;// "";


                unixtime = "0";
                cinfo = "";
                ext = "";
                //////////////////////////////////////////////////////



                if (ppurioX5.ConnectServer(ip, Convert.ToInt16(port)) < 0)
                {
                    writelog("Connect Server Fail ");
                    RESULT = "서버 연결 실패";
                }

                result = ppurioX5.SendAuth(id, pass);
                if (result.Substring(0, 2) == "NO")
                {
                    writelog("Auth Fail : " + result);
                    ppurioX5.DisConnectServer();
                    RESULT = "권한 인증 실패";
                }
                else
                {
                    writelog("Auth Success : " + result);
                }
                result = ppurioX5.SendStart();
                if (result.Substring(0, 2) == "NO")
                {
                    writelog("SendStart Fail : " + result);
                    ppurioX5.DisConnectServer();
                    RESULT = "SendStart Fail";
                }
                else
                {
                    writelog("SendStart Success : " + result);

                }


                if (device == 0)
                {
                    dt = DateTime.Now;
                    msgid = String.Format("{0}{1}{2}{3}{4}{5}",
                        dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second);

                    result = ppurioX5.SendSms("2.0", "sms", msgid, destphone, destname, subject, unixtime, sendphone, msgbody, cinfo, ext);
                    sendCheck = result;
                    if (result.Substring(0, 2) == "NO")
                    {
                        writelog("Sms Send Fail : " + result);
                        ppurioX5.SendEnd();
                        ppurioX5.DisConnectServer();
                        RESULT = "Sms Send Fail";
                    }
                    else
                    {
                        writelog("Sms Send Success : " + result);
                    }
                }
                else if (device == 5)
                {

                    string txtfilename = "";
                    string AllFileList = "";
                    dt = DateTime.Now;

                    msgid = String.Format("{0}{1}{2}{3}{4}{5}",
                                        dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second);
                    // 메세지 내용을 txt 파일로 쓴다.
                    if (msgbody != "")
                    {
                        string sfilename = msgid + ".txt";
                        string GetDate = DateTime.Now.ToShortDateString().Replace("-", "");
                        string path = "C:\\wwwroot\\FileFolder\\TTK\\MMS\\" + GetDate + "\\";

                        txtfilename = MmsTxtSave(msgbody, sfilename, path);
                        result = ppurioX5.SendFiles(path + txtfilename);
                        if (result.Substring(0, 2) == "NO")
                        {
                            writelog("MMS txt SendFile Fail : " + result);
                            ppurioX5.SendEnd();
                            ppurioX5.DisConnectServer();
                            RESULT = "MMS Send Fail";
                        }
                        else
                        {
                            AllFileList = "TXT|" + txtfilename + "\n";
                            writelog("MMS txt SendFile Success : " + result);
                        }

                    }

                    subject = "오토맨";
                    // Mms 프로토콜 전송
                    result = ppurioX5.SendMms("2.0", "mms", msgid, destphone, destname, subject, unixtime,
                                                        sendphone, AllFileList, sendname, cinfo, ext);
                    if (result.Substring(0, 2) == "NO")
                    {
                        writelog("Mms Send Fail : " + result);
                        ppurioX5.SendEnd();
                        ppurioX5.DisConnectServer();
                        RESULT = "MMS Send Fail";
                    }
                    else
                    {
                        writelog("Mms Send Success : " + result);
                        RESULT = "4100";
                    }
                }

                result = ppurioX5.SendEnd();
                ppurioX5.DisConnectServer();

                if (device == 0)
                {
                    if (sendCheck.Substring(0, 2) == "OK")
                    {
                        sendCheck = "NO1";

                        while (Report != "PI")
                        {
                            Report = LogSet(Report);
                            sendCheck = Report;
                            RESULT = SmSLog(Report, sms, RESULT);
                        }

                    }
                }


            }
            return RESULT;

        }


        private void writelog(string strmsg)
        {
            DateTime dt = DateTime.Now;
            string strdate;
            strdate = String.Format("[{0}/{1}/{2} {3}:{4}:{5}]",
                                    dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second);
            log = log + strdate + strmsg + "\r\n";
        }
        public string MmsTxtSave(String msgbody, string sfilename, string path)
        {

            DirectoryInfo Directory = new DirectoryInfo(path);

            if (!Directory.Exists)
            {
                Directory.Create();
            }
            path += sfilename;
            //StreamWriter writer = File.CreateText(path).;
            StreamWriter writer = new StreamWriter(path, true,System.Text.Encoding.GetEncoding("euc-kr"));
            writer.WriteLine(msgbody);
            writer.Close();
            return sfilename;

        }

        #region 블랙리스트 체크
        public int SmSBlackList(string Num)
        {
            return (int)Mapper.Instance().QueryForObject<int>("SmSBlackList", Num);
        }
        #endregion

        #region 로그 남기기

        public string SmSLog(string Report, SmSModel sms, string RESULT)
        {
            if (!string.IsNullOrEmpty(Report))
            {

                if (Report != "PI")
                {
                    SmSLogModel Log = new SmSLogModel();
                    string[] Reports = Report.Split('\n');
                    Log.REPORT = Report;
                    Log.REQPHONE = sms.reqphone;
                    Log.REQNAME = sms.reqname;
                    Log.CONTENT = sms.msgbody;
                    Log.REDEVICE = Reports[0].Replace(":=", ":").Split(':')[1];
                    Log.CMSGID = Reports[1].Replace(":=", ":").Split(':')[1];
                    Log.MSGID = Reports[2].Replace(":=", ":").Split(':')[1];
                    Log.PHONE = Reports[3].Replace(":=", ":").Split(':')[1];
                    Log.TO_NAME = Reports[4].Replace(":=", ":").Split(':')[1];
                    Log.UNIXTIME = Reports[5].Replace(":=", ":").Split(':')[1];
                    Log.RESULT = Reports[6].Replace(":=", ":").Split(':')[1];
                    Log.WAPINFO = Reports[7].Replace(":=", ":").Split(':')[1];
                    Log.USERDATA = Reports[8].Replace(":=", ":").Split(':')[1];
                    Log.RESULTM = ResultCodeSet(Log.RESULT);
                    if (string.IsNullOrEmpty(RESULT))
                    {
                        RESULT = Log.RESULT;
                    }

                    if (string.IsNullOrEmpty(Log.CMSGID))
                    {
                        Log.RESULTM = "실패";
                    }

                    Mapper.Instance().Insert("SmSLogInser", Log);

                    if (sms.Cerift)
                    {
                        sms.SMSSTATE = string.Format("{0}({1})", Log.RESULTM, Log.RESULT);
                        SmsCertifyInsert(sms);
                    }
                }

            }

            return RESULT;
        }


        public string ResultCodeSet(string RESULT)
        {
            if (RESULT == "4100") { RESULT = "성공"; }
            else if (RESULT == "4400") { RESULT = "음역지역"; }
            else if (RESULT == "4410") { RESULT = "잘못된 전화번호"; }
            else if (RESULT == "4420") { RESULT = "기타 에러"; }
            else if (RESULT == "4430") { RESULT = "수신 거부"; }
            else if (RESULT == "4421") { RESULT = "타임아웃"; }
            else if (RESULT == "4426") { RESULT = "재시도 한도초과"; }
            else if (RESULT == "4425") { RESULT = "단말기 호 처리중"; }
            else if (RESULT == "4401") { RESULT = "단말기전원꺼짐"; }
            else if (RESULT == "4402") { RESULT = "단말기 메시지 저장 초과"; }
            else if (RESULT == "4422") { RESULT = "단말기일시정지"; }
            else if (RESULT == "4427") { RESULT = "기타 단말기 문제"; }
            else if (RESULT == "4405") { RESULT = "단말기busy"; }
            else if (RESULT == "4423") { RESULT = "단말기착신거부"; }
            else if (RESULT == "4412") { RESULT = "착신거절"; }
            else if (RESULT == "4411") { RESULT = "NPDB에러"; }
            else if (RESULT == "4428") { RESULT = "시스템에러"; }
            else if (RESULT == "4404") { RESULT = "가입자 위치정보 없음"; }
            else if (RESULT == "4413") { RESULT = "SMSC형식오류"; }
            else if (RESULT == "4424") { RESULT = "URL SMS 미지원폰"; }
            else if (RESULT == "4414") { RESULT = "비가입자,결번,서비스정지"; }
            else if (RESULT == "4403") { RESULT = "메시지 삭제됨"; }


            return RESULT;
        }

        #endregion

        #region 로그 받기

        public string LogSet(string Report)
        {


            UDSPPURIOX5COMMLib.UdsPPurioX5Class ppurioX5_2 = new UDSPPURIOX5COMMLib.UdsPPurioX5Class();
            string id = "antae3212";
            string pass = "an8309221.";


            if (ppurioX5_2.ConnectServer("biz.ppurio.com", Convert.ToInt16("5100")) < 0)
            {
                Report = "PI";
            }
            else
            {
                ppurioX5_2.SendAuth(id, pass);
                ppurioX5_2.SendStart();
                Report = ppurioX5_2.ReportGetData();
                ppurioX5_2.SendEnd();
                ppurioX5_2.DisConnectServer();

            }

            return Report;


        }


        #endregion

        #region 인증정보 저장

        public void SmsCertifyInsert(SmSModel model)
        {
            Mapper.Instance().Insert("SmsCertifyInsert", model);
        }

        #endregion

    }



}

