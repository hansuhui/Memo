﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace Daemon
{


    [RunInstaller(true)]
    public class HInstaller : System.Configuration.Install.Installer
    {
        public HInstaller()
        {
            ServiceProcessInstaller process = new ServiceProcessInstaller();

            process.Account = ServiceAccount.LocalSystem;

            ServiceInstaller serviceAdmin = new ServiceInstaller();

            serviceAdmin.StartType = ServiceStartMode.Automatic;

            serviceAdmin.ServiceName = "BizTalkSend";

            serviceAdmin.DisplayName = "비즈톡 취소 체크 서비스";

            serviceAdmin.Description = "비즈톡 전송시 취소된 건에 대하여 3번까지 시도 그리고 차단 및 카카오톡이 안되는 사용자 SMS 및 MMS 전송";

            Installers.Add(process);
            Installers.Add(serviceAdmin);


        }


    }
}
