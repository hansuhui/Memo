﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace Daemon
{
    public partial class Service1 : ServiceBase
    {

        protected Thread m_thread;

        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            System.Diagnostics.Debugger.Launch();
            System.Diagnostics.EventLog.WriteEntry("BizTalkSend", "서비스 시작");
            ThreadStart ts = new ThreadStart(this.ServiceMain);
            Thread m_thread = new Thread(ts);
            m_thread.Start();
            base.OnStart(args);

        }

        protected override void OnStop()
        {
            System.Diagnostics.EventLog.WriteEntry("BizTalkSend", "서비스 종료");
            base.OnStop();
        }


        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        #region 예제 소스

        protected void ServiceMain()
        {
            Execute();
        }

        public virtual int Execute()
        {
            return -1;
        }

        #endregion

    }
}
