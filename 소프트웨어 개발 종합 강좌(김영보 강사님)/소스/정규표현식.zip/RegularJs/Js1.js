﻿window.onload = function() {

	/*------------------[정규 표현식!!!(2016-01-09)]----------------------------*/
	
	/*------------------[정규 표현식!!!]----------------------------*/
	//js.log("안녕하세요".match(/^안녕/).toString());
	
/*
* 	var result = "sports".match(/sp/);
	js.log(result);
	
	var pattern = /sp/;
	js.log("sports".match(pattern));*/
	
//	var result = /sp/.exec("sports");
//	js.log(result);
	
//	var pattern = /sp/;
//	js.log(pattern.exec("sports"));
	
	/*
	var regexp = new RegExp("sp");
	var result  = regexp.test("sports");
	var result2  = regexp.exec("sports");
	
	js.log(result);
	js.log(result2);
	*/

	/*-------------------------[텍스트 문자열 매치]----------------------------*/

	/*
	    설명  
	    1.매치 대상 문자열을 왼쪽에서 오른쪽으로 하나씩 매치합니다.
	    2. 매치 대상이 sports 이고 패턴도 /sports/ 이므로 매치가 되며
	    3.매치된 값이 배열로 반환됩니다.
	    ---------------------------------------
	    읽는 방법
	    1.매치 대상이 "sports"이고
	    2.s에 이어 p가 있으므로 패턴 /sp/에 매치 됩니다.
	    
	    -------------------------------
	    js.log("isArray : ", Array.isArray(result));
	    1.Array.isArray()는 배열 여부를 체크하는 자바스크립트 함수로
	    2.파라미터 값이 배열 타입이면 true를 반환합니다.
	    3.매치 결과인 result가 배열 타입인 것을 합인할수 있습니다.
	    
	    ---------------------------------
	    
	    resut = 'sports'.match(/spt/);
	    1.매치 대상이 처음 3자리가 spo이고
	    패턴이 /spt/ 이므로 매치되 지 않습니다.
	    2. 매치 되지 않으면 null을 반환하며 JS에서 null은 값입니다.
	    3.따라서 반환 값을 값으로 체크해도 에러가 발생하지 않습니다.
	    
	    ==============================
	    
	    result  'sports'.match(/s/);
	    1.매치 대상에 s가 두개 있지만
	    매치되는 것 모두가 아닌 처음 매치되는 것만 반환합니다.
	    
	     2.매치가 되면 더 이상 매치하지 않습니다.
	    */
	
	/*
	var result = "spors".match(/sports/);
	js.log(result);	
	
	result = "spors".match(/sp/);
	js.log(result);	
	js.log("isArray : ",Array.isArray(result));
	
	result = "spors".match(/spt/);
	js.log(result);	
	
	result = "spors".match(/s/);
	js.log(result);	
	*/
	
	
	/*-------------------------[i 플래그]----------------------------*/

	
	// 패턴에 플래그 i를 작성하면 대소문자룰 무시하고 매치합니다.
	// 매치가 되면 매치된 문자열을 변환하지 않고 반환합니다.
	// 대문자가 매치되면 대문자로  , 소문자가 매치되면 소문자로 반환합니다.
	/*
	var result = "SPORTS".match(/s/i); 
	
	var regexp = new RegExp("s","i");
	result = regexp.test("SPORTS");
	js.log(result);
	*/
	
	
	/*-------------------------[g 플래그]----------------------------*/
	
	/*
	var result = "SPORTS".match(/s/gi);
	js.log(result);
	
	
	//exec() 메소드는 플래그 g를 작성하더라도
	//모두가 아닌 하나만 매치를 합니다.
	var regexp = new RegExp("s",'gi');
	result = regexp.exec("SPORTs");
	js.log(result);
	*/
	
	/*-------------------------[m 플래그]----------------------------*/
	/*
	설명
    var value = 'sports\nMultiLine\nMultiLine';
    1.\n은 줄 분리 문자로 줄이 분리되어 표시됩니다.
    sports
    MultiLine
    MultiLine
    ========================================
    var result = value.match(/^Multi/);
    1.^은 매치 대상 첫 문자부터 패턴을 매치합니다.
       문자열 중간에 패턴이 매치될 수있어도 매치하지 않습니다.
       2.value 변수의 첫 문자가 spports이므로
       파라미터에 작성한 "Multi"가 매치되지 않습니다.
       
     ------------------------------------------------
     [실행 결과] 2번
     
     result = value.match(/^Multi//m);
     1.플래그 m은 각 줄에 매치하고
     처음 매치되는 문자열을 반환합니다.
     2.^Multi가 두개 매치될 수 있는데 하나만 매치합니다.
     -----------------------------------
     [실행 결과] 3번
     result = value.match(/^Multi/gm);
     1.g 플래그가 매치를 반복하므로
     -m 플래그로 각 줄에 매치를 박복하게 되어 모두 매치됩니다.
     
     -----------------------------------
     result = value.match(/Multi/);
     1. 문자열로 매치하면 m 플래그와 같습니다.
     모든 문자열에 매치를 하지만
     하나가 매치되면 더 이상 매치하지 않습니다.
     
     ]
	*/
	/*
    var value = 'sports\nMultiLine\nMultiLine';
    var result = value.match(/^Mutil/);
    js.log(result);
    
    result = value.match(/^Multi/m);
    js.log(result);
    
    result = value.match(/^Multi/gm);
    js.log(result);

    result = value.match(/^Multi/);
    js.log(result);

    */
    
	/*-------------------------[대체(|)]----------------------------*/
	/*
	설명
	var value = '12_34_56'.match(/23|34|56/);
	1.패턴의 23으로 23을 매치합니다.
	2.매치가 되지 않으므로 34를 매치하며 매치가 됩니다.
	매치된 인덱스 값은 3입니다.
	3.다시 56으로 매치하며 매치가 됩니다.
	매치된 인덱스 값은 6입니다.
	4.34의 인덱스가 56보다 작으므로 34를 반환합니다.
	
	--------------------------------------
	result = '12_34_56'.match(/23|56|34/);
	1.23은 매치되지 않으며 56은 매치 됩니다.
	매치된 인덱스 값은 6입니다.
	2.매치가 되었으므로 이 값을 반환해야 하나
	[실행결과] 2번에 56이 아닌 34가 출력되었습니다.
	
	3.56이 매치되더라도 34를 매치하여 매치됩니다.
	매치된 인덱스 값은 3입니다.
	4.34의 매치 인덱스와 56의 매치 인덱스를 비교합니다.
	34의 인덱스가 작으므로 , 즉 매치 대상 문자열의  앞에 있으므로 34가 반환됩니다.
	
	5.이를 정규 표현식 최적화 마커니즘이라고 합니다.
	
	-----------------------------------------------
	
	result = '12_34_56'.match(/12|34|56/g);
	1.12와 34와 56이 매치되므로 12가 반환되어야 하지만
	2.g 플래그를 지정하면 매치된 것을 모두 반환합니다.
	
	---------------------------------------
	result = /c|bc|a|abc/.exec("abc");
	1.c|bc|a 에서 a의 매치 인덱스가 작으므로 a가 반환됩니다.
	2.한편 a|abc는 매치된 인덱스가 같습니다.
	이대 먼제 매치된 문자열이 반환됩니다.
*/
	/*
	var  result = '12_34_56'.match(/23|34|56/);
	js.log(result);
	
	result = '12_34_56'.match(/23|56|34/);
	js.log(result);
	
	result = '12_34_56'.match(/12|34|56/g);
	js.log(result);
	
	result = /c|bc|a|abc/.exec("abc");
	js.log(result);
	
	result = /c|bc|abc|a/.exec("abc");
	js.log(result);*/
	
	
	/*-------------------------[앞뒤 문자 매치)]----------------------------*/

	/*
	설명
	var result = 'sports'.match(/.s/);
	1./.s/
	s가 매치 되어야 하고 s앞에 문자가 있어야 합니다.
	2.sports에서 앞에 s는 매치가 되지만
	점(.) 위치에 문자가 없으므로 매치되지 않습니다.
	3.끝의 s는 s앞에 t가 있으므로 매치가 되어 [ts]가 반환됩니다.
	----------------------------------------
	result = 'sports'.match(/s./);
	1./s./
	s가 매치가 되어야 하고 s뒤에 문자가 있어야 합니다.
	2.sports에서 앞에 s는 s뒤에 문자가 있으므로
	매치되어 sp가 반환됩니다.
	3.끝의 s는 s뒤에 문자가 없으므로 매치되지 않습니다.
	
	-------------------------
	result = 'sop, sap, sac, sp'.match(/s.p/g);
	
	1./s.p/g
	점(.)앞에 s가 있고 점(.) 뒤에 p가 있으면서
	점(.) 위치에 문자가 있는 문자열을 반복하여 매치합니다.
	
	2.sop와 sap는 패턴에 매치됩니다.
	3.sac는 sa는 매치되나 c가 매치되지 않습니다.
	4.sp는 점(.) 위치에 문자가 없으므로 매치되지 않습니다.
	
	*/
	/*
	var result = "sports".match(/.s/);
	js.log(result);
	
	result = 'sports'.match(/s./);
	js.log(result);

	result = 'sop, sap, sac, sp'.match(/s.p/g);
	js.log(result);

	result = 'sop, sap, sac, sp'.match(/./g);
	js.log(result.toString());
	*/
	
	
	/*-------------------------[공백 문자]----------------------------*/
/*
	var result = '\u0009'.match(/\t/);
	js.log("result : ", result, "Length :", result.length);
	*/
	
	/*-------------------------[줄 분리자]----------------------------*/
/*
	var result = "\u000A".match(/\n/);
	js.log(result);
	*/
	
	/*-------------------------[코딩 문제]----------------------------*/
	/*
	반환 값을 받기 위한 정규 표현식을 작성하세요.
	매치 대상 : "ABCDE ABCXE"
	ㅡmatch() 메소드를 사용하세요.
	
	반환값 : [BC,DE,BC]
	조건 : 대체(|)패턴 문자 사용
	
	반환 값 : [ABCE, BCXE]
	조건 : dot(.) 패턴 문자 사용
	
	*/
	
	/*
	var value = "ABCDE ABCXE";
	var result = value.match(/BC|DE|BC/g);
	js.log(result);
	result = value.match(/ABC.E|BC.E/g);
	js.log(result);*/
	
	
	/*-------------------------[처음부터 매치]----------------------------*/
/*
	설명
	var result = '12_34_12'.match(/^12/);
	1.패턴의 12가 매치 대상의 처음에 있으므로 매치됩니다.
	===================================
	result = "12_34_12".match(/^34/);
	1.패턴의 34가 매치 다상에 있지만
	중간에 있으므로 매치 되지 않습니다.
	===================================
	
	var value = 'first\u000aStart\u000aStart';
	resutl = values.match(/^Start/m);
	1.\u000a는 줄바꿈을 나타냅니다.
	2.m 플래그를 작성하지 않으면
	처음 한 줄만 매치하르모 매치되지 않습니다.
	3.m 플래그를 작성해야 줄 전체에 매치합니다.
	
*/	
	/*
	var result = '12_34_12'.match(/^12/);
	js.log(result);

	result = '12_34_12'.match(/^34/);
	js.log(result);
	
	var value = 'first\u000aStart\u000aStart';
	result = value.match(/^Start/m);
	js.log(result);
	*/
	
	/*-------------------------[끝에 매치]----------------------------*/
/*
		var result = '12_34_56'.match(/56$/);
		1.패턴에 56이 매치 대상의 끝에 있으므로 매치됩니다.
		
		--------------------------------------
		result = '12_34_12'.match(/34$/);
		1,패턴의 34가 매치 대상에 있지만
		중간에 있으므로 매치되지 않습니다
*/	
	/*
	var result = '12_34_56'.match(/56$/);
	js.log(result);
	var result = '12_34_56'.match(/34$/);
	js.log(result);
	*/
	
	
	/*-------------------------[63개 문자 매치]----------------------------*/

	/*
	var  result = 'A12A 12B 12A'.match(/12\B/g);
	1.패턴 " /12\B
	2.12에 이어서 63개 문자가 있으면 매치됩니다.
	3.g 플래그를 지정했으므로 A12A, 12B , 12A 모두 매치됩니다.
	4.매치된 63개 문자는 반환하지 않습니다.
	
	-----------------------------------
	
	result = 'A12 B12 12'.match(/12\B/g);
	1.매치가 되지 않는 것은
	12다음에 63개 문자가 없기 때문입니다.
	----------------------------------
	result = 'A12 12 C12'.match(/\B12/g);
	1,패턴 : /\B12/
	2.63개 문자가 이어서 12가 있으면 매치됩니다.
	3.g 플래그를 지정했으므로 A12, C12가 매치됩니다.
	4.가운데 12는 12앞이 공백 문자이므로 매치되지 않습니다.
	5.매치된 63개 문자는 반환하지 않습니다.
	----------------------------------
	result = 'A12B 12D E12F'.match(/\B12\B/g);
	1.패턴 : /\B12\B/
	2.12의 앞뒤에 63개 문자가  매치되어야 매치로 처리되므로
	12D는 매치되지 않습니다.
	
	
	*/
	/*
	
	var  result = 'A12A 12B 12A'.match(/12\B/g);
	js.log(result);
	
	result = 'A12 B12 12'.match(/12\B/g);
	js.log(result);
	
	result = 'A12 12 C12'.match(/\B12/g);
	js.log(result);

	result = 'A12B 12D E12F'.match(/\B12\B/g);
	js.log(result);
	*/
	
	
	/*-------------------------[단어 경계]----------------------------*/

	/*
	var result = 'A12 12B 12C'.match(/12\b/g);
	1.패턴 : /12\b/g
	2.12에 이어서 63개 이외 문자가 있으면 매치됩니다.
	12B, 12C는 12 다음에 B/C가 있으므로 매치 되지 않습니다,
	
	------------------------
	result = 'A12 12B 12'.match(/\b12/g);
	1.매치 대상 끝은 63개 이외 문자로 인식합니다.
	2."A12 "와 "12"가 매치됩니다.
	------------------------
	
	result = '12 12 C12'.match(/\b12/g);
	1.매치 대상 처음은 63개 이외 문자로 인식합니다.
	2.처음의 12는 앞에 문자가 없지만 63개 문자로 인식합니다.
	3.중간의 12는 앞에 공백 문자가 있으므로 매치됩니다.
	4.C12는 63개 문자이므로 매치되지 않습니다.
	
	------------------------
	result = 'A12 12 C12'.match(/\b12\b/g);
	1.패턴:/\b12\b/g
	2.12가 매치되고 12의 앞뒤가 63개 이외 문자일 떄 매치되므로
	가운데의 " 12 "만 매치됩니다.
   */	
	
	/*
	
	var result = 'A12 12B 12C'.match(/12\b/g);
	js.log(result);

	result = 'A12 12B 12'.match(/\b12/g);
	js.log(result);

	result = '12 12 C12'.match(/\b12/g);
	js.log(result);

	result = 'A12 12 C12'.match(/\b12\b/g);
	js.log(result);
*/
	
	/*-------------------------[match()]----------------------------*/

	/*
	설명
	var result = "34_12_56".match(/12/);
	1.매치 대상 "34_12_56"에 12를 매치하고
	-매치가 되면 매치된 문자열을 배열로 반환합니다.
	
	-----------------------------
	js.log(result.index);
	1.반환된 배열은 [1,2,3] 형태의 배열이 아니라
	Array 오브젝트입니다.
	즉, Array 처리를 위한 프로퍼티와 메소드가 포함되어 있습니다.
	2.index 프로퍼티는 매치된 인덱스를 제공합니다.
	-------------------------
	js.log(result.input);
	1.input 프로퍼티는 매치 대상 문자열 값을 제공합니다.
	
	--------------------------
	for(var name in result){
	js.log(name, ':', result[name]);
	}
	1.result Arraty 오브젝트에 설정되 프로퍼티를 출력합니다.
	2.[실행결과 ] 4번의 "0:12"에서 0은 배열의 첫 번째를 의미합니다.
	
	*/
	/*
	function returnValue(){
		return "Sports";
	}
	function returnPattern(){
		return /sp/i;		
	}
	
	var result = returnValue().match(/sp/i);
	js.log(result);
	result = "Sports".match(returnPattern());
	js.log(result);
	*/
	
	/*-------------------------[search()]----------------------------*/

	/*
	var result = "CD_AB_EF".search(/AB/);
	js.log(result);
	
	result = "CD_AB_AB".search(/AB/g);
	js.log(result);
	
	result = "AB_CD_CD".search(/CD$/);
	js.log(result);
	result = "AB_CD".search(/EF/g);
	js.log(result);
	*/
	
	/*-------------------------[split()]----------------------------*/
	
	
/*
	var result = "12_34_56".split('_');
	js.log(result);
	
	result = "12_34_56".split(/_/);
	js.log(result);
	
	result = "12_34_78".split('S');
	js.log(result);
	
	result = "12_34_78".split();
	js.log(result);
	*/
	
	/*
	var result = "12_34_56".split('');
	js.log(result);
	result = "12_34_78".split('78');
	js.log(result);
	
	//소괄호 안에 넣으면 분리자를 포함한다!!
	result = "12A34A56".split(/(A)/);
	js.log(result);
	result = "12_34_56".split('_',2);
	js.log(result);
	*/
	
	
	/*-------------------------[replace()]----------------------------*/

	/*
	var result = "12_34_12".replace("12",77);
	js.log(result);

	result = "12_34_12".replace(/12/g,77);
	js.log(result);
	
	function rerurnValue(){
		return 'AA';
	}

	result = "12_34_12".replace(/12/g,rerurnValue());
	js.log(result);
	
	*/
	
	/*-------------------------[test()]----------------------------*/
/*
	var result = /12/.test("12_34_56");
	js.log(result);
	*/
	
	/*-------------------------[exec()]----------------------------*/
	
/*	var result = /12/.exec("12_34_12");
	js.log(result);
	js.log(result.index);
	js.log(result.input);
	
	result = /12/g.exec("12_34_12");
	js.log(result);
*/	
	
	/*-------------------------[하나 이상 매치]----------------------------*/
	
	/*
	var result = 'AAAC AAC'.match(/A+/);
	js.log(result);
		
	result = 'AAAC AAC'.match(/A+/g);
	js.log(result);
	*/
	
	/*-------------------------[모든 문자 매치]----------------------------*/
/*
	var result = 'abcde가나다'.match(/.+/);
	js.log(result);
		
*/	
	
	/*-------------------------[코딩 문제]----------------------------*/
	
	/*
	요구사항
	1.값 전체가 숫자인 것을 체크하는 정규 표현식을 작성하세요.
	2.함수의 파라미터로 값을 받습니다.
	값이 모두 숫자이면 true를 출력하고
	하나라도 숫자가 아니면 false를 출력하세요.
	값의 자릿수는 유동적입니다.
	
	3.힌트&조건
	숫자 패턴 문자 :\d
	test() 메소드 사용
	
	chack("1234");
	chack("1234AA");
	chack("AA1234");
	chack("");
	*/
	
	/*
	function chack(val){
		var s = /^\d+$\d/.test(val);
		return s;
	}
	
	js.log(chack("1234"));
	js.log(chack("1234AA"));
	js.log(chack("AA1234"));
	js.log(chack(""));
	*/
	
	/*-------------------------------[정규표현식 최적화]----------------------------*/
/*
	var result = "abcAB".match(/.+AB/);
	js.log(result);
		
	result = "010-100-0151".match(/\d+-\d+-\d+/);
	js.log(result);
*/
	
	/*-------------------------------[없거나 하나 이상 매치]----------------------------*/

	//	var result = "AAAC".match(/A*/);
//	js.log(result);
//	
//	result = "AABAAAC".match(/A*/);
//	js.log(result);
//	
//	result = "12AB_12EFG".match(/12C*/g);
	//	js.log(result);
	//	result = "123AB_12EFG".match(/123C*/);
	//	js.log(result);
	//	result = "ABC_123".match(/123C*/);
	//	js.log(result);

/*-------------------------------[없거나 하나만 매치]----------------------------*/
	
//	var result = "123AAA".match(/123S?/);
//	js.log(result);
//
//	result = "123AAA".match(/123A?/);
//	js.log(result);
//	
//	result = "123aaa".match(/123A*/i);
//	js.log(result);
//	
//	result = "123sk".match(/123S?K/i);
//	js.log(result);
//	result = "123SSSK".match(/123S?K/);
//	js.log(result);
//	result = "123SSSK".match(/123S*K/);
//	js.log(result);
	
	
	/*-------------------------------[욕심 많은 매치 매커니즘]----------------------------*/
/*	
	var result = "123ABCD".match(/.?AB/);
	js.log(result);
	
*/
	
	/*-------------------------------[수에 매치]----------------------------*/
	
/*	
  var result = "AAA".match(/A{2}/);
	js.log(result);

	//A가 4개 있어야 매치가 되는데 3개 이므로 매치되지 않습니다.
	result = "AAA".match(/A{4}/);
	js.log(result);
	
	//A가 2개이고 이어서 K가 있으므로 매치가 됩니다.
	//한편, 앞에서 부터 매치하면 AAA가 3개 이므로 매치되지 않습니다.
	//전체가 매치되기 위해서는 K가 매치되어야 하고
	//앞으로 이동하면서 A가 2개 매치되어야 합니다.
	//정규 표현식 최적화는 뒤에서 앞으로 매치 합니다.
	result = "AAAKK".match(/A{2}K/);
	js.log(result);
	*/
	
	/*-------------------------------[수 이상에 매치]----------------------------*/
	
	/*
	var result ="AAAA".match(/A{2,}/);
	js.log(result);
	
	//A가 4개 이상 매치되어야 하나 4개만 매치되므로
	//매치 실패가 되며 null를 반환합니다.
   result ="AAAA".match(/A{5,}/);
	js.log(result);
	
	//B가 매치되어야 하고 그 앞에 A가 2개 이상 매치되어야 합니다.
	result ="AAAABB".match(/A{2,}B/);
	js.log(result);
	*/
	
	/*-------------------------------[매치 구간 지정]----------------------------*/
/*
	var result = "AAAAA".match(/a{2,4}/i);
	js.log(result);
	
	result = "AAA".match(/a{2,4}/i);
	js.log(result);
	
	//매치 대상에 A가 없지만,
	//최소 매치 수가 0이므로 매치에 성공합니다.
	//단,매치된 문자가 없으므로 빈 문자열을 반환합니다.
	result = "CCC".match(/a{0,2}/i);
	js.log(result);
	*/
	
	
	/*-------------------------------[한 번만 매치]----------------------------*/
	
	/*
	 var result = "AAAAAC".match(/AA+?/);
	js.log(result);
	
	result = "AAAAAC".match(/AA+/);
	js.log(result);
	
	*/
	
	
		/*-------------------------------[한 번만 매치]----------------------------*/

	/*
	//앞에 작성한 C를 매치하지 않으므로 AB만 반환
	var result ="ABCABC".match(/ABC*?/);
	js.log(result);
	
	//ABZ로 매치하면 매치가 되지 않지만 Z를 매치하지 않으므로 AB만 반환
	result ="ABCABC".match(/ABZ*?/);
	js.log(result);
	
	//빈문자열을 반환
	//배열 길이는 1
	result ="ABCABC".match(/a*?/i);
	js.log(result);
	js.log(result.index);
	js.log(result.length);
	
	//최소로 매치하지만 K가 매치되어야 합니다
	//왼쪽에서 오른쪽으로 매치하므로
	//첫 번째의 A와 K로 매치하면 매치가 되지 않습니다.
	//다시 두 번째 A와 K로 매치하면 매치가 되지 않습니다.
	//또 다시 세 번째 A와 K로 매치하면 매치가 되며
	//이때 매치된 A를 모아 즉. AA와 AK를 결합하여 반환합니다.
	// 정규 표현식의 최적화 알고리즘 입니다.
	result ="AaaAAKK".match(/A*?K/i);
	js.log(result);
	
	result ="ABCABC".match(/ABC*?C/);
	js.log(result);
	*/
	
	
	/*-------------------------------[숫자 범위 무시]----------------------------*/
/*
	var result = "AAAAA".match(/A{1,}/i);
	js.log(result);
	
	result = "AAAAA".match(/A{1,}?/i);
	js.log(result);

	result = "AAaaA".match(/A{1,5}?/i);
	js.log(result);
	*/
	
	/*-------------------------------[문자 집합]----------------------------*/
/*
	//패턴 : [ABK]
	//매치 대상에 A또는 B 또는 K가 있으면 매치로 처리합니다.
	//패턴에 작성한 순서로 매치하며
	//매치된 문자 하나를 배열로 반환
	var result = "ABCDE".match(/[ABK]/g);
	js.log(result);
	
	//[]안에 값을 지정하지 않으면 null를 반환합니다
	result = "abcde".match(/[]/i);
	js.log(result);
	
	//패턴에 작성한 순서로 매치하면 B,A,C가 매치되지만
	//반환은 매치된 것중에서 매치 대상에 작성한 순서를 적용합니다.
	//A를 처음에 작성했으므로 A가 반환됩니다.
	result = "abcde".match(/[bac]/i);
	js.log(result);
	
	
	//g 플로그를 작성했으며 모든 문자를 매치합니다.
	//매치 대상에 장성한 순서로 반환합니다.
	result = "정규표현식".match(/[표정]/g);
	js.log(result);
	js.log(result.length);
*/
	/*-------------------------------[패턴 문자를 문자화]----------------------------*/
/*
	//1+ 패턴이 아니라  1 또는 +로 매치
	var result = "111".match(/[1+]/g);
	js.log(result);
	
	//. 또는 ? 또는 1로 매치
	result = "?12".match(/[.?1]/g);
	js.log(result);
*/

	/*-------------------------------[패턴 문자를 문자화]----------------------------*/
	
	
	

};

