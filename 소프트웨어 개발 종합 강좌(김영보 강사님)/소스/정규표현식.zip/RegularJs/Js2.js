﻿window.onload = function() {

	/*-------------------------------[구간]----------------------------*/
/*
	//0에서 5까지가 매치 대상에 하나라도 있으면 매치로 처리
	//패턴 순서가 아닌 매치 대상 순서로 반화
	var result = "54321".match(/[0-5]/);
	js.log(result);
	
	//g 플래그를 사용했으므로
	//A-E 까지의 매치된 문자를 반환
	//매치 대상을 기준으로 왼쪽에서 오른쪽으로 하나씩 이동하면서 매치
	result = "CDBC".match(/[A-E]/g);
	js.log(result);
	
	//"-" 앞 또는 뒤에 값을 작성하지 않으면 문자로 인식
	//[-3]은 [0-3]이 아니라
	//-과 3을 매치 기준 문자로 인식
	//3이 먼저와서 3을 반환
	result = "73-21".match(/[-3]/);
	js.log(result);
	
	//매치 대상이 없어서 null을 반환
	result = "721".match(/[-3]/);
	js.log(result);
	
	//3이 매치 되어서 3을 반환
	result = "7321".match(/[3-]/);
	js.log(result);
	*/
	
	/*-------------------------------[백스페이스]----------------------------*/
/*
	//유니코드 \u0008 값은 백스페이스로 [\b]로 매치됩니다.
	//백스페이스가 보이지 않으므로 1번에 값이 표시되지 않았지만 
	//2번에 출력이 된 것은 값이 있다는 것을 의미합니다.
	var result = "\u0008".match(/[\b]/);
	js.log(result);
	js.log(result.length);
	
	result = /[\b]/.test("\u0008");
	js.log(result);
	*/
	
	/*-------------------------------[코딩 문제]----------------------------*/

	/*
	요구 사항
	함수의 파라미터로 값을 받습니다.
	값 전체가 영문 대소문자이면 true를, 아니면 false를 출력하세요.
	값 전체: 매치 대상의 처음부터 마지막까지
	
	힌트&조건
	test() 메소드를 사용
	check("ABCD");
	check("abcd");
	check("ABcd");
	check("123");
	check("12AB");
	check("AB12");

	추가 요구 사항
	선택으로 위 문제를 완료하신 분에 해당됩니다.
	값에 숫자를 추가해서 체크하세요.
	*/
/*
	function check(val){
		return /^[a-zA-Z]+$/.test(val);
	}
	
	function Numcheck(val){
		return /^[a-zA-Z0-9]+$/.test(val);
	}
	
	js.log(check("ABCD"));
	js.log(check("abcd"));
	js.log(check("ABcd"));
	js.log(check("123"));
	js.log(check("12AB"));
	js.log(check("AB12"));
	js.log(Numcheck("123"));
	js.log(Numcheck("12AB"));
	js.log(Numcheck("AB12"));
	
*/	
	
	
	/*-------------------------------[제외]----------------------------*/
/*
	//A를 제외한 B를 매치 첫번째 문자
	var result = "ABCD".match(/[^A]/);
	js.log(result);
	
	//AB를 제외한 C를 매치 첫번째 문자
	result = "ABCDE".match(/[^ABD]/);
	js.log(result);
	
	//1부터 4를 제외하고 g 플래그를 사용했으므로
	//그외에 숫자를 반환
	result = "15257".match(/[^1-4]/g);
	js.log(result);
	
	//정표를 제외한 문자를 매치
	result = "정규표현식".match(/[^정표]/g);
	js.log(result);
	
*/	
	
	/*-------------------------------[텍스트 추출]----------------------------*/

	/*
	function GetText(param){
		//< : < 문자에 매치
		//\/ : 슬래시 문자
		// ? : /가 없어도 매치, 있으면 하나만 매치
		//[^>] : 이외 문자에 매치
		//+ : ? 이외 문자를 연속하여 매치
		// > : > 문자에 매치
		// ig : ig 플래그(대소문자 안가리고 전제 반복)
		return param.replace(/<\/?[^>]+>/ig,"");
	}
	
	var result= GetText("<div id='sports'>축구</div>");
	js.log(result);*/
	
	
	/*-------------------------------[패턴 문자의 문자화]----------------------------*/

	/*
	//^A는 첫문자에 매치하므로 null
	var result = "^ABC".match(/^A/);
	js.log(result);
	
	
	//패턴 앞에 \가 있어서 문자로 인식되어
	//^A를 출력
	result ="B^AC".match(/\^A/);
	js.log(result);
	
	//패턴에 \\A가 있으므로(두개라서!!) 
	// \A가 매치 되어서 출력
	result = "\\AB".match(/\\A/);
	js.log(result);
	
	
	result = new RegExp("\\^B").exec('A^BC');
	js.log(result);
	
	result = new RegExp("\^A").exec("ABC");
	js.log(result);
	
	*/
	
	/*-------------------------------[숫자만 매치]----------------------------*/

	/*
	//\d는 숫자만 인식 하므로 처음으로 오는 숫자인 1을 매치
	var result = "A123".match(/\d/);
	js.log(result);
	
	//전체가 숫자것만 반환
	result = "123".match(/^\d+$/);
	js.log(result);
	
	*/
	
	/*-------------------------------[숫자 이외 매치]----------------------------*/
/*
	//숫자가  아닌것을 매치한다 첫 문자인 A를 매치
	var result = "1ABC23".match(/\D/);
	js.log(result);
	
	
	//숫자가 아닌것을 전체 매치 
	//배열로 A,B,C를 매치
	result = "1ABC23".match(/\D/g);
	js.log(result);
	
	
	//숫자가 있으므로 null을 반환
	result = "ABC3".match(/^\D+$/);
	js.log(result);
	
	//숫자가 없으므로 ABC를 매치
	result = "ABC".match(/^\D+$/);
	js.log(result);
		
		*/
		
	/*-------------------------------[보이지 않는 문자]----------------------------*/
/*
	//\u0009는 탭(Tap)보이지 않는 문자 이므로 true
	var result = /\s/.test("\u0009");
	js.log(result);
	
	//az는 모이는 문자이므로 null을 반환
	result = 'az'.match(/\s/);
	js.log(result);
*/		
	/*-------------------------------[보이지 문자]----------------------------*/
		/*
	//\u0009는 탭 , \u0061는 소문자 a이므르 보이는 문자인 a를 매치
	var result = '\u0009\u0061'.match(/\S/);
	js.log(result);
	
	//"한글"은 보이는 문자이므로 매치
	result = "한글".match(/\S/);
	js.log(result);
		
		*/
		
		
	/*-------------------------------[63개 문자만 매치]----------------------------*/

/*		var result = "%_aA1".match(/\w/);
		js.log(result);
*/		

		/*-------------------------------[63개 이외 매치]----------------------------*/

/*			var result = "%_aA1".match(/\W/);
			js.log(result);
*/			
		
	/*-------------------------------[매치 결과 캡처]----------------------------*/

	/*
	//()안의 A로 매치합니다.
	//매치가 되면 매치된 값을 캡처합니다.
	//캡처된 값을 반환할 배열의 두 번째 엘리먼트에 설정합니다.
	//캡처된 값으로 매치합니다.
	//매치가 되며 반환할  배열의 첫 번째에 설정합니다.
	var result = "ABC".match(/(A)/);
	js.log(result);
	
	
	//()두개 작성한 패턴입니다.
	//A가 매치되면 3개의 엘리먼트가 반환됩니다.
	//((A))에서 A로 매치합니다,.
	//매치된 A를 캡처하고 반환할 3번째 엘리먼트에 설정합니다.
	//((A))는 (A)가 됩니다.
	//(A)에서 A가 매치되므로
	//A를 캡처하고 2번째 엘리먼트에 설정합니다.
	// /A/가 남게 됩니다.
	//남아 있는 A가 매치되며 첫 번째 엘리먼트에 설정합니다.
	//이런 과정을 통해[A,A,A]가 반환됩니다.
	result = "ABC".match(/((A))/);
	js.log(result);
	
	//(C|P)와(D|P)가 매치되면 3개의 엘리먼트가 반환됩니다.
	//(C|P)로 매치되면 C가 매치됩니다.
	//매치된 C가 캡처되고 반환할 배열의 2번째에 설정합니다.
	//(D|Q)로 매치하면 D가 매치됩니다.
	//매치된 D가 캡처되고 반환할 배열의 3번째에 설정합니다.
	//소괄호 밖의 문자와 캡처한 값을 연결하면 ABCDEF가 됩니다.
	//ABCDEF로 매치하면 매치가 되며
	//반환할 배열의 첫 번째에 설정합니다.
	//()를 먼저 매치하는데 매치된 값이 반환할 배열의 처음에
	//설정되지 않는 이유를 계속해서 살펴 봅니다.
	
	result = "ABCDEF".match(/AB(C|P)(D|Q)EF/);
	js.log(result);
		*/
	
	/*-------------------------------[undefined 설정 메커니즘]----------------------------*/

	
	// 소괄호() 수남큼 2번째 인덱스부터 undefined를 설정합니다.
	//["",undefined,undefined,undefined]
	//밖에서 안으로, 왼쪽에서 오른쪽으로 undefined를 설정합니다.
	//2번째 인덱스가 (()|())의 undefined 이고
	//3번째가 (ball)의 undefined 4번째가 base의 undefined
	//처음에 매치하면 base가 매치됩니다.
	//baseball에서 base가 앞에 있으므로 ball이 아닌 base가 매치됩니다.
	//["",undefined,undefined,base]가 형태가 됩니다.
	//((ball)|base) 형태가 됩니다.
	
	//다시 매치하면 base가 매치됩니다.
	//base는 전체 소괄호()의 매치 값이므로 2번째 인덱스에 설정됩니다.
	//["",base,undefined,base]; 형태가 됩니다.
	
	//마지막으로 base로 baseball을 매치하게 되며
	//매치가 되므로 첫 번째 인덱스에 값이 설정됩니다.
	//[base,base,undefined,base] 형태가 됩니다.
	//(ball)은 한번도 매치되지 않으므로 undefined가 그대로 유지 됩니다.
	
	
	//인덱스가 base가 빨라서 ball은 매치가 되지 않음!!!
	
	/*
	var result = /((ball)|(base))/.exec("baseball");
	js.log(result);
	
	*/
	
/*-------------------------------[백레퍼런스]----------------------------*/

	/*
	 var result = "ABCDEF_CD".match(/AB(C|K)(D|X)EF_/);
	js.log(result);
	
	//C,D를 캡처한다
	//ABCDEF_에 참조한 C와 D을 넣어서
	//ABCDEF_CD가 매치 된다.
	result = "ABCDEF_CD".match(/AB(C|K)(D|X)EF_\1\2/);
	js.log(result);
	*/
	
	
	/*-------------------------------[RegExp.$숫자]----------------------------*/
	
/*	
  var result = "ABCDEF".match(/AB(C|M)(D|P)EF/);
	js.log(result);
	
	
	//캡처한 값
	js.log(RegExp.$1);
	js.log(RegExp.$2);

	//캡처가 되지 않아서 빈값을 반환
	js.log(RegExp.$3);
	
	//프로퍼티가 존재하지 않아서 undefined를 반환
	js.log(RegExp.$0);
	js.log(RegExp.$12);*/
	
	
	/*-------------------------------[콤마 삽입]----------------------------*/
/*
	var pattern = /(^[+-]?\d+)(\d{3})/;
	function insertComma(val){
		var str= val.toString();
		while(pattern.test(str)){
			str = str.replace(pattern,'$1'+','+"$2");
		}
		return str;
	}
	var result = insertComma(123456789);
	js.log(result);
	
	result = insertComma(-123456789);
	js.log(result);
	
	result = insertComma(-1234567);
	js.log(result);
	
*/
	
	
/*-------------------------------[백트래킹]----------------------------*/

	
	// 패턴이 swiA?m 이므로 swiAm 또는 swim이면 매치
	//매치 대상 첫 번째인 s를 매치하고
	//매치된 s를 콜로저에 저장합니다.
	//그리고 다음에 매치할 인덱스인 1을 lastIndex에 설정합니다
	//이런 방법으로 s,w,i를 매치합니다.
	//swi가 클로저에 저장되어 있으며
	//lastIndex는 m을 가리키게 되며
	//매치할 패턴은 A?(하나를 하던지없던지)입니다
	//A?로 매치 대상에 남아 있는 m을 매치하면 매치가 됩니다.
	//매치가 되는 것까지 좋으나 lastIndex 값이 증가하게 되어
	//매치 대상 swim 끝에 lastIndex가 위치하게 됩니다.
	//한편 아직 swiA?m의 m을 위치하지 않았습니다.
	//lastIndex가 참조하는 위치의 문자에 swiA?m의 m을 매치하면
	//매치가 되지 않아 전체가 실패하게 됩니다. 이때 정규 표현식 최적화 매커니즘을 사용합니다.
	
	//lastIndex에서 1을 마이너스합니다.
	//그러면 lastIndex가 매치 대상 swim의 m을 참조하게 됩니다.
	//참조한 m과 swiA?m의 m을 매치하게 되어 매치가 되므로
	//클로저에 설정되어 이는 swi와 매치된 m을 연결하여 반환합니다.
	
	//만약 이떄에도 매치가 안되면
	//같은 방법으로 lastIndex 값을 줄여 매치 위치를 변경하고 매치합니다.
	//이 개념이 욕심 많은 패턴의 백트래킹 입니다.
	
	/*
	var  result = 'swim'.match(/swiA?im/);
	js.log(result);
	*/
	
	
	/*
	욕심 없는 패턴 문자는 되도록 적게 매치하려는
	 특성으로 인해 s만 매치하게 됩니다. 
	*/
	/*
	var result = 'swim'.match(/s.*?/);
	js.log(result);
	*/
	
	/*
	위와 다른 것은 패턴의 마지막에 m이 있는 점입니다.
	즉, m까지 매치되어야 전체가 성공합니다.
	m이 매치되는 과정을 설펴봅니다.
	
	패턴을 매치 대상에 매치하면 첫 번째 s가 매치되므로
	클로저에 s가 설정되고 lastIndex는 w를 가리키게 됩니다.
	
	.*?dptj *? 되도록 매치하지 않으려는 특성으로 인해
	일단 다음 패턴으로 넘어갑니다.
	여기까지가 바로 앞 표현식의 매치 과정입니다.
	
	한편 다음에 m이 매치되어야 전체가 매치되므로
	정규 표현식의 최적화가 발동하게 되며
	이때 백트래킹을 사용하게 됩니다.
	
	매치된 s와 m을 여결하여 매치합니다.
	
	매치가 되지 않으므로 패턴으로 돌아와 .*?로 매치합니다.
	swim의 w가 매치되며 클로저에 설정합니다.
	
	다시 클로저에 설정된 문자열(sw)와 m을 연결하여 매치합니다.
	
	그래도 매치가 되지 않으므로 패턴으로 돌아와 ,*?로 매치합니다.
	swim의 i가 매치되며 클로저에 설정합니다.
	
	
	*/
	/*
	result = "swim".match(/s.*?m/);
	js.log(result);
	*/
	
	
	/*-------------------------------[최대로 매치]----------------------------*/
	
	
	
	
	//인덱스가 빠른 AA를 만나서 캡처를 하고 반환
	
	/*
	var result = "AABAAC".match(/(AA|AABAAC|B)/);
	js.log(result);
	*/
	
	//앞 코드와 차이는 패턴에 *가 있는 점입니다.
	//*패턴 문자는 지정한 문자가 없어도 매치로 처리하고
	//있으면 모두 매치합니다.
	//최대로 매치하려는 특성을 갖고 있습니다.
	
	//AA가 매치되면 AA를 클로저에 저장합니다.
	//이때 포인터는 매치 대상의 B에 위치하게 됩니다.
	//패턴의 다음 값은 AABAAC이며 매치 대상에 있지만
	//클로저의 AA에 첨부하면 AAAABAAC가 되므로 매치되지 않습니다.
	//이렇게 연결하여 매치하는 것은 하나라도 더 매치하려는 특성 때문입니다.
	
	//패턴 끝에 B가 있으며 클로저의 AA에 연결하면 AAB가 됩니다.
	// 매치된 AA보다 AAB가 더 많이 매치되므로 현시점에서 반환값은 AAB 입니다.
	//패턴을 끝까지 매치하였다고 끝내지 않습니다.
	//포인터가 가리키고 있는 인덱스부터 AA를 매치합니다.
	//매치가 되므로 클로저의 최종 값에 첨부하여 매치합니다.
	//즉,AABAA로 매치합니다.
	//매치가 되며 이 시점은 반환갑은 [AABAA.AA]가 됩니다.
	
	//아직 B가 남았으므로 클로저의 AABAA에 B를 첨부하여 매치합니다.
	//매치가 되지 않으므로 매치된 최종값인 [AABAA,AA]를 받환합니다.
	
	
	//result = "AABAAC".match(/(AA|AABAAC|B)*/);
	//js.log(result);
	
	
	//패턴의 AA는 매치되며 다음의 BA는 매치되지 않습니다.
	//BA 작성은 설명을 위해 의도적으로 작성한 것입니다.
	//B가 매치되면 클로저에 AAB가 설정됩니다.
	//패턴 끝의 C를 AAB에 첨부허면 AABC가 되고 매치되지 않습니다.
	//따라서[AAB,B]가 반환됩니다.
	
	//var result = "AABKKCD".match(/(AA|BA|B|C)*/);
	//js.log(result);
	
	
	//처음 AA를 매치 하고 다음 AABA을 매치한다
	//최종적으로 많이 매치한거!!! 마지막 캡처!!!
	
	//result = "AABACA".match(/(AA|BA|CA|B|A|C)*/);
//	js.log(result);;
//	if(RegExp.$1 =="CA"){
//	js.log("올커니 !!!!! 캡처 : ",RegExp.$1);
//	}
	
	
	/*-------------------------------[전방 매치]----------------------------*/
	
	//(?=C)에서 ?=는 대상에서 C를 찾습니다.
	//그리고 (?=C)는 앞에 작성한 AB에 C를 연결하여 매치합니다
	//매치가 되면 C는 반환하지 않고 AB만 반환합니다.
	/*
	var result = "ABCC".match(/AB(?=C)/);
	js.log(result);
	*/
	
	
	//C를 찾고 앞에를 비교 ABD != AB null
	/*
	result = "ABDCC".match(/AB(?=C)/);
	js.log(result);
	*/
	// C 앞에 걸 찾는 AB = AB 맞고 뒤에 CH = CH 
	//ABCH 
	/*
	result = "ABCH".match(/AB(?=C)CH/);
	js.log(result);
	*/
	
	
	/*-------------------------------[전방  부정 매치]----------------------------*/

	//EF를 찾고 ABCD 와 AB를 비교
	//거짓이면 AB를 준다!!
	var result = "ABCDEF".match(/AB(?!EF)/);
	js.log(result);
	
	//EF를 찾고 앞에 AB과 AB를 비교 
	//참이면 null을 반환
	result = "ABEF".match(/AB(?!EF)/);
	js.log(result);
	
	
};


/*-------------------------------[코딩문제]----------------------------*/

/*
요구 사항
파라미터 값으로 63개 문자가 들어오며
10~50자까지 사용할 수 있습니다.
뒤에서 부터 문자를 4개씩 ##으로 구분하여 출력하세요

힌트
\w: 63개 패턴 문자
*/


/*
var pattern = /(^\w+)(\w{4})/;

function test(val){
	debugger;
	if(val.trim() =="" ||val == null){
		js.log("값을 입력해주세요");
		return false;
	}
	if(val.length <=9 ||val.length >=51){
		js.log("길이가 10이하 거나 50 이상입니다.");
		return false;
	}
	
	if(typeof val =="string"){
		if(pattern.test(val)){
		while(pattern.test(val)){
			val = val.replace(pattern,'$1'+'##'+"$2");
		}
		js.log(val);
		}else{
			js.log("실패");
		}
	}else{
		js.log("실패");
	}
	
	if(event != undefined){
		event.target.value = "";
	}
	
}*/
