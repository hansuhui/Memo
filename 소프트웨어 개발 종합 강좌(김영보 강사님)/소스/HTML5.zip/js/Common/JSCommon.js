﻿//작성자 H
//작성일 2015-12=12




//오브젝트 생성
var HanObj = {};


//String 함수
//String 오브젝트인지 확인하고 String 오브젝트이면 true를 반환




//String 오브젝트인지 확인하고 String 오브젝트이면 true를 반환
function isStringObj(obj) {
    var Check = false;
    if (typeof Obj === "string") { Check = true; }
    return Check;
}



